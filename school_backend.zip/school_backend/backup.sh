#!/bin/bash
# Daily rotating backup (keeps the last 7 days):  bash backup.sh
cd "$(dirname "$0")"
mkdir -p ~/db_backups
[ -f db.sqlite3 ] && cp db.sqlite3 ~/db_backups/daily_$(date +%a).sqlite3 && echo "Backup done"
