# Hosting on PythonAnywhere (HTTPS is provided automatically)
1. Create an account at pythonanywhere.com. Use a paid plan for real use; the free plan has a very small daily CPU quota (testing only).
2. Files tab -> upload school_backend.zip. Consoles -> Bash:  unzip school_backend.zip
3. In Bash (replace USERNAME with your username):
   cd school_backend
   python3.13 -m venv venv        (if not available use python3.12 and pick the same version in the Web tab)
   source venv/bin/activate
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py collectstatic --noinput
4. Web tab -> Add a new web app -> Manual configuration -> the same Python version.
   Source code: /home/USERNAME/school_backend
   Virtualenv:  /home/USERNAME/school_backend/venv
5. Open the WSGI configuration file, delete everything, and paste:
   import os, sys
   sys.path.insert(0, '/home/USERNAME/school_backend')
   os.environ['DJANGO_SETTINGS_MODULE'] = 'config.settings'
   os.environ['DEBUG'] = '0'
   os.environ['SECRET_KEY'] = 'put-a-long-random-text-here'
   os.environ['ALLOWED_HOSTS'] = 'USERNAME.pythonanywhere.com'
   os.environ['CSRF_ORIGINS'] = 'https://USERNAME.pythonanywhere.com'
   from django.core.wsgi import get_wsgi_application
   application = get_wsgi_application()
6. Click Reload on the Web tab. Open: https://USERNAME.pythonanywhere.com/panel/
7. Server URL for the mobile app: https://USERNAME.pythonanywhere.com
Backup: download school_backend/db.sqlite3 regularly.
