from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from rest_framework.routers import DefaultRouter
from core import views as v, web as w, pwa, pages, records as rc, school as sc

r = DefaultRouter()
r.register("super/schools", v.SchoolAdminVS, basename="super-schools")
r.register("super/admins", v.AdminUserVS, basename="super-admins")
r.register("notices", v.NoticeVS, basename="notices")
r.register("timetable", v.TimetableVS, basename="timetable")
r.register("datesheet", v.DateSheetVS, basename="datesheet")
r.register("syllabus", v.SyllabusVS, basename="syllabus")
r.register("lessonplans", v.LessonPlanVS, basename="lessonplans")
r.register("leaves", v.LeaveVS, basename="leaves")
r.register("classes", v.ClassRoomVS, basename="classes")
r.register("students", v.StudentVS, basename="students")
r.register("teachers", v.TeacherVS, basename="teachers")
r.register("users", v.UserVS, basename="users")
r.register("attendance", v.AttendanceVS, basename="attendance")
r.register("fees", v.FeeVS, basename="fees")
r.register("marks", v.MarkVS, basename="marks")
r.register("diary", v.DiaryVS, basename="diary")

urlpatterns = [
    path("panel/alerts/", pages.alerts_page, name="panel-alerts"),
    path("panel/chats/", pages.chats_list, name="panel-chats"),
    path("panel/chats/<int:uid>/", pages.chat_thread, name="panel-chat"),
    path("panel/badges/", pages.badges, name="panel-badges"),
    path("panel/my/<str:section>/", pages.my_section, name="panel-my"),
    path("panel/accounts/", pages.accounts_page, name="panel-accounts"),
    path("panel/school/", sc.school_page, name="panel-school"),
    path("panel/school/save/", sc.school_save, name="panel-school-save"),
    path("panel/slides/add/", sc.slide_add, name="panel-slide-add"),
    path("panel/slides/<int:pk>/delete/", sc.slide_delete, name="panel-slide-delete"),
    path("panel/slides/<int:pk>/img/", sc.slide_img, name="panel-slide-img"),
    path("panel/docs/", sc.docs_page, name="panel-docs"),
    path("panel/docs/add/", sc.doc_add, name="panel-doc-add"),
    path("panel/docs/<int:pk>/delete/", sc.doc_delete, name="panel-doc-delete"),
    path("panel/docs/<int:pk>/file/", sc.doc_file, name="panel-doc-file"),
    path("panel/child/<int:pk>/", pages.choose_child, name="panel-child"),
    path("panel/rec/<str:kind>/", rc.rec_list, name="rec-list"),
    path("panel/rec/<str:kind>/add/", rc.rec_add, name="rec-add"),
    path("panel/rec/<str:kind>/import/", rc.rec_import, name="rec-import"),
    path("panel/rec/<str:kind>/template/", rc.rec_template, name="rec-template"),
    path("panel/rec/<str:kind>/export/", rc.rec_export, name="rec-export"),
    path("panel/rec/<str:kind>/delete-all/", rc.rec_delete_all, name="rec-delete-all"),
    path("panel/rec/results/subjects/add/", rc.rec_subject_add, name="rec-subject-add"),
    path("panel/rec/results/subjects/<int:pk>/delete/", rc.rec_subject_delete, name="rec-subject-delete"),
    path("panel/rec/<str:kind>/<int:pk>/edit/", rc.rec_edit, name="rec-edit"),
    path("panel/rec/<str:kind>/<int:pk>/delete/", rc.rec_delete, name="rec-delete"),
    path("panel/m/students/", RedirectView.as_view(url="/panel/rec/students/")),
    path("panel/m/fees/", RedirectView.as_view(url="/panel/rec/fees/")),
    path("panel/m/marks/", RedirectView.as_view(url="/panel/rec/results/")),
    path("panel/excel/", RedirectView.as_view(url="/panel/rec/students/")),
    path("manifest.webmanifest", pwa.manifest),
    path("sw.js", pwa.service_worker),
    path("pwa/icon-<int:size>.png", pwa.icon),
    path("", RedirectView.as_view(url="/panel/")),
    path("admin/", admin.site.urls),
    path("api/login/", v.login), path("api/activate/", v.activate), path("api/me/", v.me), path("api/change_password/", v.change_password),
    path("api/branding/", v.branding), path("api/super/branding/", v.super_branding),
    path("api/", include(r.urls)),
    # PC web panel (Super Admin + School Admin)
    path("panel/", w.home, name="panel-home"),
    path("panel/login/", w.login_page, name="panel-login"),
    path("panel/super/", w.login_page, {"who": "super"}, name="panel-login-super"),
    path("panel/admin/", w.login_page, {"who": "admin"}, name="panel-login-admin"),
    path("panel/teacher/", w.login_page, {"who": "teacher"}, name="panel-login-teacher"),
    path("panel/student/", w.login_page, {"who": "student"}, name="panel-login-student"),
    path("panel/activate/", w.activate_page, name="panel-activate"),
    path("panel/user/add/", w.user_add, name="panel-user-add"),
    path("panel/user/<int:pk>/toggle/", w.user_toggle, name="panel-user-toggle"),
    path("panel/user/<int:pk>/password/", w.user_password, name="panel-user-password"),
    path("panel/school/<int:pk>/toggle/", w.school_toggle, name="panel-school-toggle"),
    path("panel/password/", w.my_password, name="panel-password"),
    path("panel/attendance/", w.attendance_page, name="panel-attendance"),
    path("panel/diary/add/", w.diary_add, name="panel-diary-add"),
    path("panel/m/<str:key>/", w.mod_list, name="panel-mod"),
    path("panel/m/<str:key>/import/", w.mod_import, name="panel-mod-import"),
    path("panel/m/<str:key>/template/", w.mod_template, name="panel-mod-template"),
    path("panel/m/<str:key>/add/", w.mod_form, name="panel-mod-add"),
    path("panel/m/<str:key>/<int:pk>/edit/", w.mod_form, name="panel-mod-edit"),
    path("panel/m/<str:key>/<int:pk>/delete/", w.mod_delete, name="panel-mod-delete"),
    path("panel/leaves/", w.leaves_page, name="panel-leaves"),
    path("panel/leaves/add/", w.leave_apply, name="panel-leave-add"),
    path("panel/leaves/<int:pk>/review/", w.leave_review, name="panel-leave-review"),
    path("panel/branding/", w.branding_save, name="panel-branding"),
    path("panel/logout/", w.logout_page, name="panel-logout"),
    path("panel/school/add/", w.school_add, name="panel-school-add"),
    path("panel/school/<int:pk>/code/", w.school_code, name="panel-school-code"),
    path("panel/school/<int:pk>/extend/", w.school_extend, name="panel-school-extend"),
]
