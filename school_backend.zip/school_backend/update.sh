#!/bin/bash
# Safe update for PythonAnywhere:  bash update.sh
# backup database -> git pull -> install -> migrate -> reload.  Your live data is never reset.
set -e
cd "$(dirname "$0")"
mkdir -p ~/db_backups
BACKUP=""
if [ -f db.sqlite3 ]; then
  BACKUP=~/db_backups/before_update_$(date +%Y-%m-%d_%H%M%S).sqlite3
  cp db.sqlite3 "$BACKUP"
  echo "1/5 Backup saved: $BACKUP"
  # if the database file was committed to git by mistake, let git pull work without touching your backup
  if git ls-files --error-unmatch db.sqlite3 >/dev/null 2>&1; then git checkout -- db.sqlite3; fi
fi
git pull
# the live database always wins: put it back exactly as it was before the update
if [ -n "$BACKUP" ]; then cp "$BACKUP" db.sqlite3; echo "2/5 Live database kept"; fi
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
touch /var/www/*wsgi.py 2>/dev/null && echo "Done. App reloaded." || echo "Done. Now click Reload on the Web tab."
