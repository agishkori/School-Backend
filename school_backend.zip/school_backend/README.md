# School Management Backend (Django REST)

    pip install -r requirements.txt
    python manage.py migrate
    python manage.py createsuperuser      # this becomes the Super Admin
    python manage.py runserver 0.0.0.0:8000

PC panel (browser): http://127.0.0.1:8000/panel/
Role links: /panel/super/  /panel/admin/  /panel/teacher/  /panel/student/

Flow: Super Admin creates a school and its admin (or an activation code) -> Admin creates teacher and
student/parent accounts, classes and students (or uploads Excel files) -> Teachers mark attendance,
marks and diary -> Parents view their children's data.
Mobile API auth header: Authorization: Token <token>

Phones: open https://YOUR-SERVER/panel/ in Chrome and tap "Install App" (or menu -> Install app).
It is a normal installable web app: every server update shows up automatically, no new APK.
