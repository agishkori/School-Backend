#!/bin/bash
# Update without GitHub:  1) upload school_backend.zip to /home/<you>/ (PythonAnywhere Files tab)   2) bash ~/School-Backend/school_backend/update_local.sh
# Database (db.sqlite3), media/ and venv are not inside the zip, so they are never touched.
{
set -e
ZIP=~/school_backend.zip
[ -f "$ZIP" ] || { echo "Upload school_backend.zip to your home folder first ($ZIP)"; exit 1; }
PROJECT=~/School-Backend/school_backend
mkdir -p ~/db_backups
[ -f "$PROJECT/db.sqlite3" ] && cp "$PROJECT/db.sqlite3" ~/db_backups/before_update_$(date +%Y-%m-%d_%H%M%S).sqlite3 && echo "Backup saved in ~/db_backups"
unzip -o -q "$ZIP" -d ~/School-Backend
cd "$PROJECT"
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
touch /var/www/*wsgi.py 2>/dev/null && echo "Done. App reloaded." || echo "Done. Now click Reload on the Web tab."
exit
}
