"""Phone-style pages: home icon grid, read-only sections, alerts, chats."""
from decimal import Decimal
from django.contrib import messages
from django.db.models import Q, Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .models import *
from .ui import ROLE_LABEL, TILES
from .web import panel

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def home_page(request):
    u, s, today = request.user, request.user.school, timezone.localdate()
    hr = timezone.localtime().hour
    ctx = {"greet": "Good Morning" if hr < 12 else "Good Afternoon" if hr < 17 else "Good Evening", "today": today, "school": s,
           "tiles": TILES[u.role], "role_label": ROLE_LABEL[u.role],
           "notices": Notice.objects.filter(school=s).order_by("-date", "-id")[:3],
           "notice_url": "/panel/m/notices/" if u.role == "SCHOOL_ADMIN" else "/panel/my/notices/"}
    if u.role == "PARENT":
        kids = list(Student.objects.filter(school=s, parent=u).select_related("classroom"))
        for k in kids:
            k.absent = Attendance.objects.filter(student=k, status="A", date__gte=today.replace(day=1)).count()
            agg = FeeRecord.objects.filter(student=k).aggregate(a=Sum("amount"), p=Sum("paid_amount"))
            k.due = (agg["a"] or Decimal(0)) - (agg["p"] or Decimal(0))
        ctx["kids"] = kids
    elif u.role == "TEACHER":
        ctx["slots"] = Timetable.objects.filter(school=s, teacher=u, day=today.isoweekday()).select_related("classroom")
    else:
        agg = FeeRecord.objects.filter(student__school=s).aggregate(a=Sum("amount"), p=Sum("paid_amount"))
        ctx["stats"] = [("Students", Student.objects.filter(school=s).count()),
                        ("Teachers", User.objects.filter(school=s, role="TEACHER").count()),
                        ("Parents", User.objects.filter(school=s, role="PARENT").count()),
                        ("Absent today", Attendance.objects.filter(student__school=s, date=today, status="A").count()),
                        ("Fees due (Rs)", f"{(agg['a'] or 0) - (agg['p'] or 0):,.0f}")]
    return render(request, "panel/home.html", ctx)


ALLOWED = {"attendance": ("PARENT",), "fees": ("PARENT",), "results": ("PARENT",), "diary": ("PARENT",), "syllabus": ("PARENT",),
           "timetable": ("PARENT", "TEACHER"), "datesheet": ("PARENT", "TEACHER"),
           "notices": ("PARENT", "TEACHER", "SCHOOL_ADMIN"), "students": ("TEACHER",)}
TITLES = {"attendance": "Attendance", "fees": "Fees", "results": "Results", "diary": "Diary / Homework", "timetable": "Timetable",
          "datesheet": "Date Sheet", "syllabus": "Syllabus", "notices": "Notice Board", "students": "Students"}


@panel
def my_section(request, section):
    u = request.user
    if u.role not in ALLOWED.get(section, ()):
        return redirect("panel-home")
    s = u.school
    kids = list(Student.objects.filter(school=s, parent=u).select_related("classroom")) if u.role == "PARENT" else []
    rooms = [k.classroom for k in kids if k.classroom]
    ctx = {"section": section, "title": TITLES[section], "kids": kids}
    if section == "notices":
        ctx["rows"] = Notice.objects.filter(school=s).order_by("-date", "-id")[:100]
    elif section == "timetable":
        qs = Timetable.objects.filter(school=s).select_related("classroom", "teacher")
        rows = list(qs.filter(classroom__in=rooms) if u.role == "PARENT" else qs.filter(teacher=u))
        for x in rows:
            x.dayname = DAYS[(x.day - 1) % 7]
        ctx["rows"] = rows
    elif section == "datesheet":
        qs = DateSheet.objects.filter(school=s).select_related("classroom")
        ctx["rows"] = qs.filter(classroom__in=rooms) if u.role == "PARENT" else qs
    elif section == "syllabus":
        ctx["rows"] = Syllabus.objects.filter(school=s, classroom__in=rooms).select_related("classroom")
    elif section == "diary":
        ctx["rows"] = Diary.objects.filter(school=s, classroom__in=rooms).select_related("classroom").order_by("-date", "-id")[:60]
    elif section == "attendance":
        ctx["rows"] = Attendance.objects.filter(student__in=kids).select_related("student").order_by("-date")[:90]
        ctx["summary"] = [{"kid": k, "present": Attendance.objects.filter(student=k, status="P").count(),
                           "absent": Attendance.objects.filter(student=k, status="A").count(),
                           "leave": Attendance.objects.filter(student=k, status="L").count()} for k in kids]
    elif section == "fees":
        rows = list(FeeRecord.objects.filter(student__in=kids).select_related("student").order_by("-due_date"))
        tot, paid = sum((f.amount for f in rows), Decimal(0)), sum((f.paid_amount for f in rows), Decimal(0))
        ctx.update(rows=rows, total=tot, paid=paid, due=tot - paid)
    elif section == "results":
        ctx["rows"] = Mark.objects.filter(student__in=kids).select_related("student").order_by("student__name", "exam_name", "subject")
    elif section == "students":
        ctx["rows"] = Student.objects.filter(school=s).select_related("classroom", "parent").order_by("classroom__name", "roll_no")[:400]
    return render(request, "panel/my.html", ctx)


@panel
def accounts_page(request):
    u = request.user
    if u.role != "SCHOOL_ADMIN":
        return redirect("panel-home")
    users = User.objects.filter(school=u.school, role__in=["TEACHER", "PARENT"]).select_related("school").order_by("role", "first_name")
    return render(request, "panel/accounts.html", {"users": users})


@panel
def excel_page(request):
    if request.user.role != "SCHOOL_ADMIN":
        return redirect("panel-home")
    return render(request, "panel/excel.html")


# ---------------- Alerts ----------------
@panel
def alerts_page(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    items = list(Notification.objects.filter(user=u)[:100])
    for n in items:
        n.new = not n.is_read
    Notification.objects.filter(id__in=[n.id for n in items if n.new]).update(is_read=True)
    return render(request, "panel/alerts.html", {"items": items})


# ---------------- Chats ----------------
def _name(u):
    base = u.first_name or u.username
    if u.role == "PARENT":
        kids = ", ".join(k.name for k in u.children.all()[:3])
        return f"{base} (Parent of {kids})" if kids else base
    return f"{base} ({'Teacher' if u.role == 'TEACHER' else 'Admin'})"


def contacts(u):
    base = User.objects.filter(school_id=u.school_id, is_active=True).exclude(pk=u.pk)
    admins = Q(role="SCHOOL_ADMIN")
    if u.role == "SCHOOL_ADMIN":
        return base.filter(role__in=["TEACHER", "PARENT"])
    if u.role == "PARENT":
        rooms = Student.objects.filter(parent=u).exclude(classroom=None).values("classroom")
        tids = set(ClassRoom.objects.filter(id__in=rooms).exclude(class_teacher=None).values_list("class_teacher", flat=True)) | \
            set(Timetable.objects.filter(classroom__in=rooms).exclude(teacher=None).values_list("teacher", flat=True))
        return base.filter(admins | Q(pk__in=tids)) if tids else base.filter(admins | Q(role="TEACHER"))
    rooms = ClassRoom.objects.filter(school_id=u.school_id).filter(
        Q(class_teacher=u) | Q(id__in=Timetable.objects.filter(teacher=u).values("classroom")))
    if not rooms.exists():
        return base.filter(admins | Q(role="PARENT"))
    pids = set(Student.objects.filter(classroom__in=rooms).exclude(parent=None).values_list("parent", flat=True))
    return base.filter(admins | Q(pk__in=pids))


def can_chat(u, other):
    if u.school_id != other.school_id or not other.is_active or other.pk == u.pk or other.role == "SUPER_ADMIN":
        return False
    return contacts(u).filter(pk=other.pk).exists() or \
        ChatMessage.objects.filter(Q(sender=u, recipient=other) | Q(sender=other, recipient=u)).exists()


@panel
def chats_list(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    seen, unread = {}, {}
    for m in ChatMessage.objects.filter(Q(sender=u) | Q(recipient=u)).select_related("sender", "recipient").order_by("-id")[:400]:
        other = m.recipient if m.sender_id == u.id else m.sender
        seen.setdefault(other.id, {"user": other, "last": m})
        if m.recipient_id == u.id and not m.is_read:
            unread[other.id] = unread.get(other.id, 0) + 1
    convs = [{"user": v["user"], "label": _name(v["user"]), "last": v["last"], "unread": unread.get(k, 0),
              "mine": v["last"].sender_id == u.id} for k, v in seen.items()]
    new = [{"user": c, "label": _name(c)} for c in contacts(u).exclude(pk__in=seen.keys()).order_by("first_name", "username")[:200]]
    return render(request, "panel/chats.html", {"convs": convs, "new": new})


@panel
def chat_thread(request, uid):
    u = request.user
    other = get_object_or_404(User, pk=uid)
    if u.role == "SUPER_ADMIN" or not can_chat(u, other):
        messages.error(request, "You cannot chat with this person")
        return redirect("panel-chats")
    if request.method == "POST":
        text = request.POST.get("text", "").strip()[:2000]
        if text:
            ChatMessage.objects.create(school=u.school, sender=u, recipient=other, text=text)
        return redirect("panel-chat", uid=uid)
    ChatMessage.objects.filter(sender=other, recipient=u, is_read=False).update(is_read=True)
    msgs = list(ChatMessage.objects.filter(Q(sender=u, recipient=other) | Q(sender=other, recipient=u)).order_by("-id")[:200])[::-1]
    return render(request, "panel/chat.html", {"other": other, "label": _name(other), "msgs": msgs})


@panel
def badges(request):
    u = request.user
    a = Notification.objects.filter(user=u, is_read=False)
    c = ChatMessage.objects.filter(recipient=u, is_read=False)
    la, lc = a.order_by("-created_at").first(), c.order_by("-id").first()
    title = body = ""
    if la and (not lc or la.created_at >= lc.created_at):
        title, body = la.title, la.body
    elif lc:
        title, body = f"Message from {lc.sender.first_name or lc.sender.username}", lc.text[:100]
    return JsonResponse({"alerts": a.count(), "chats": c.count(), "title": title, "body": body})
