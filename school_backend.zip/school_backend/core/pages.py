"""Phone-style pages: home icon grid, read-only sections, alerts, chats."""
from decimal import Decimal
from django.contrib import messages
from django.db.models import Q, Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .models import *
from .ui import ROLE_LABEL, TILES
from .people import children_of, fmt_cnic
from .school import docs_for
from .web import panel, purge_diary

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def home_page(request):
    purge_diary()
    u, s, today = request.user, request.user.school, timezone.localdate()
    hr = timezone.localtime().hour
    ctx = {"greet": "Good Morning" if hr < 12 else "Good Afternoon" if hr < 17 else "Good Evening", "today": today, "school": s,
           "tiles": TILES[u.role], "role_label": ROLE_LABEL[u.role],
           "notices": Notice.objects.filter(school=s).order_by("-date", "-id")[:3],
           "slides": Slide.objects.filter(school=s)[:12], "notice_url": "/panel/m/notices/" if u.role == "SCHOOL_ADMIN" else "/panel/my/notices/"}
    if u.role == "PARENT":
        kids, cur = children_of(request)
        if cur:
            cur.absent = Attendance.objects.filter(student=cur, status="A", date__gte=today.replace(day=1)).count()
            fb = FeeBalance.objects.filter(student=cur).first()
            cur.due = fb.balance if fb else None
            cur.fee_updated = fb.updated_at if fb else None
        ctx.update(kids=kids, cur=cur)
    elif u.role == "TEACHER":
        ctx["slots"] = Timetable.objects.filter(school=s, teacher=u, day=today.isoweekday()).select_related("classroom")
    else:
        due = FeeBalance.objects.filter(student__school=s).aggregate(b=Sum("balance"))["b"] or 0
        ctx["stats"] = [("Students", Student.objects.filter(school=s).count()),
                        ("Teachers", User.objects.filter(school=s, role="TEACHER").count()),
                        ("Parent accounts", User.objects.filter(school=s, role="PARENT").count()),
                        ("Absent today", Attendance.objects.filter(student__school=s, date=today, status="A").count()),
                        ("Fees due (Rs)", f"{due:,.0f}")]
    return render(request, "panel/home.html", ctx)


ALLOWED = {"attendance": ("PARENT",), "fees": ("PARENT",), "results": ("PARENT",), "diary": ("PARENT",), "syllabus": ("PARENT",),
           "timetable": ("TEACHER",), "datesheet": ("PARENT", "TEACHER"),
           "notices": ("PARENT", "TEACHER", "SCHOOL_ADMIN"), "students": ("TEACHER",)}
TITLES = {"attendance": "Attendance", "fees": "Fees", "results": "Results", "diary": "Diary / Homework", "timetable": "Timetable",
          "datesheet": "Date Sheet", "syllabus": "Syllabus", "notices": "Notice Board", "students": "Students"}


@panel
def my_section(request, section):
    u = request.user
    if u.role not in ALLOWED.get(section, ()):
        return redirect("panel-home")
    return render(request, "panel/my.html", _my_ctx(request, section))


def _my_ctx(request, section):
    u = request.user
    s = u.school
    kids_all, cur = children_of(request) if u.role == "PARENT" else ([], None)
    kids = [cur] if cur else []
    rooms = [k.classroom for k in kids if k.classroom]
    ctx = {"section": section, "title": TITLES[section], "kids": kids_all, "cur": cur}
    if section == "notices":
        ctx["rows"] = Notice.objects.filter(school=s).order_by("-date", "-id")[:100]
    elif section == "timetable":
        qs = Timetable.objects.filter(school=s).select_related("classroom", "teacher")
        rows = list(qs.filter(classroom__in=rooms) if u.role == "PARENT" else qs.filter(teacher=u))
        for x in rows:
            x.dayname = DAYS[(x.day - 1) % 7]
        ctx["rows"] = rows
    elif section == "datesheet":
        ctx["pdfs"] = docs_for(u, "datesheet")
        qs = DateSheet.objects.filter(school=s).select_related("classroom")
        ctx["rows"] = qs.filter(classroom__in=rooms) if u.role == "PARENT" else qs
    elif section == "syllabus":
        ctx["rows"] = Syllabus.objects.filter(school=s, classroom__in=rooms).select_related("classroom")
    elif section == "diary":
        purge_diary()
        ctx["rows"] = Diary.objects.filter(school=s, classroom__in=rooms).select_related("classroom").order_by("-date", "-id")[:60]
    elif section == "attendance":
        ctx["rows"] = Attendance.objects.filter(student__in=kids).select_related("student").order_by("-date")[:90]
        ctx["summary"] = [{"kid": k, "present": Attendance.objects.filter(student=k, status="P").count(),
                           "absent": Attendance.objects.filter(student=k, status="A").count(),
                           "leave": Attendance.objects.filter(student=k, status="L").count()} for k in kids]
    elif section == "fees":
        fb = FeeBalance.objects.filter(student=cur).first() if cur else None
        ctx["fb"] = fb
    elif section == "results":
        ctx["pdfs"] = docs_for(u, "result")
        marks = list(Mark.objects.filter(student=cur).order_by("exam_name", "subject")) if cur else []
        exams = sorted({m.exam_name for m in marks})
        exam = request.GET.get("exam") if request.GET.get("exam") in exams else (exams[-1] if exams else "")
        rows = [m for m in marks if m.exam_name == exam]
        tot, got = sum(m.total for m in rows), sum(float(m.obtained) for m in rows)
        ctx.update(exams=exams, exam=exam, rows=rows, tot=tot, got=round(got, 2), pct=round(got / tot * 100, 1) if tot else 0)
    elif section == "students":
        ctx["rows"] = Student.objects.filter(school=s).select_related("classroom").order_by("classroom__name", "roll_no")[:400]
    return ctx


@panel
def accounts_page(request):
    u = request.user
    if u.role != "SCHOOL_ADMIN":
        return redirect("panel-home")
    tab = request.GET.get("tab") if request.GET.get("tab") in ("students", "teachers") else ""
    if not tab:
        return render(request, "panel/accounts.html", {"tab": "", "n_t": User.objects.filter(school=u.school, role="TEACHER").count(),
                                                       "n_s": User.objects.filter(school=u.school, role="PARENT").count()})
    q = User.objects.filter(school=u.school, role="TEACHER" if tab == "teachers" else "PARENT").order_by("first_name", "username")
    users = list(q)
    if tab == "students":
        for x in users:
            x.kids = ", ".join(k.name for k in x.children.all())
            x.cnic = fmt_cnic(x.username)
    return render(request, "panel/accounts.html", {"users": users, "tab": tab})


@panel
def choose_child(request, pk):
    if request.user.role == "PARENT" and request.method == "POST":
        if Student.objects.filter(pk=pk, parent=request.user).exists():
            request.session["child"] = pk
    nxt = request.POST.get("next", "")
    return redirect(nxt if nxt.startswith("/panel/") else "panel-home")


# ---------------- Alerts ----------------
@panel
def alerts_page(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    items = list(Notification.objects.filter(user=u)[:100])
    for n in items:
        n.new = not n.is_read
    Notification.objects.filter(id__in=[n.id for n in items if n.new]).update(is_read=True)
    return render(request, "panel/alerts.html", {"items": items})


# ---------------- Chats ----------------
def _name(u):
    base = u.first_name or u.username
    if u.role == "PARENT":
        kids = ", ".join(k.name for k in u.children.all()[:3])
        return f"{base} (Parent of {kids})" if kids else base
    return f"{base} ({'Teacher' if u.role == 'TEACHER' else 'Admin'})"


def contacts(u):
    base = User.objects.filter(school_id=u.school_id, is_active=True).exclude(pk=u.pk)
    admins = Q(role="SCHOOL_ADMIN")
    if u.role == "SCHOOL_ADMIN":
        return base.filter(role="TEACHER")
    if u.role == "PARENT":
        rooms = Student.objects.filter(parent=u).exclude(classroom=None).values("classroom")
        tids = set(ClassRoom.objects.filter(id__in=rooms).exclude(class_teacher=None).values_list("class_teacher", flat=True)) | \
            set(Timetable.objects.filter(classroom__in=rooms).exclude(teacher=None).values_list("teacher", flat=True))
        return base.filter(pk__in=tids) if tids else base.filter(role="TEACHER")
    rooms = ClassRoom.objects.filter(school_id=u.school_id).filter(
        Q(class_teacher=u) | Q(id__in=Timetable.objects.filter(teacher=u).values("classroom")))
    if not rooms.exists():
        return base.filter(admins | Q(role="PARENT"))
    pids = set(Student.objects.filter(classroom__in=rooms).exclude(parent=None).values_list("parent", flat=True))
    return base.filter(admins | Q(pk__in=pids))


def pair_ok(a, b):
    """Students / parents may chat ONLY with teachers."""
    if "PARENT" in (a.role, b.role):
        return {a.role, b.role} == {"PARENT", "TEACHER"}
    return "SUPER_ADMIN" not in (a.role, b.role)


def can_chat(u, other):
    if u.school_id != other.school_id or not other.is_active or other.pk == u.pk or not pair_ok(u, other):
        return False
    return contacts(u).filter(pk=other.pk).exists() or \
        ChatMessage.objects.filter(Q(sender=u, recipient=other) | Q(sender=other, recipient=u)).exists()


@panel
def chats_list(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    seen, unread = {}, {}
    for m in ChatMessage.objects.filter(Q(sender=u) | Q(recipient=u)).select_related("sender", "recipient").order_by("-id")[:400]:
        other = m.recipient if m.sender_id == u.id else m.sender
        if not pair_ok(u, other):
            continue
        seen.setdefault(other.id, {"user": other, "last": m})
        if m.recipient_id == u.id and not m.is_read:
            unread[other.id] = unread.get(other.id, 0) + 1
    convs = [{"user": v["user"], "label": _name(v["user"]), "last": v["last"], "unread": unread.get(k, 0),
              "mine": v["last"].sender_id == u.id} for k, v in seen.items()]
    new = [{"user": c, "label": _name(c)} for c in contacts(u).exclude(pk__in=seen.keys()).order_by("first_name", "username")[:200]]
    return render(request, "panel/chats.html", {"convs": convs, "new": new})


@panel
def chat_thread(request, uid):
    u = request.user
    other = get_object_or_404(User, pk=uid)
    if u.role == "SUPER_ADMIN" or not can_chat(u, other):
        messages.error(request, "You cannot chat with this person")
        return redirect("panel-chats")
    if request.method == "POST":
        text = request.POST.get("text", "").strip()[:2000]
        if text:
            ChatMessage.objects.create(school=u.school, sender=u, recipient=other, text=text)
        return redirect("panel-chat", uid=uid)
    ChatMessage.objects.filter(sender=other, recipient=u, is_read=False).update(is_read=True)
    msgs = list(ChatMessage.objects.filter(Q(sender=u, recipient=other) | Q(sender=other, recipient=u)).order_by("-id")[:200])[::-1]
    return render(request, "panel/chat.html", {"other": other, "label": _name(other), "msgs": msgs})


@panel
def badges(request):
    u = request.user
    a = Notification.objects.filter(user=u, is_read=False)
    c = ChatMessage.objects.filter(recipient=u, is_read=False)
    if u.role in ("PARENT", "SCHOOL_ADMIN"):
        c = c.filter(sender__role="TEACHER")
    la, lc = a.order_by("-created_at").first(), c.order_by("-id").first()
    title = body = ""
    if la and (not lc or la.created_at >= lc.created_at):
        title, body = la.title, la.body
    elif lc:
        title, body = f"Message from {lc.sender.first_name or lc.sender.username}", lc.text[:100]
    return JsonResponse({"alerts": a.count(), "chats": c.count(), "title": title, "body": body})
