import base64
import re
import secrets
from datetime import date, timedelta
from django.utils import timezone
from decimal import Decimal
from functools import wraps
from django.contrib import messages
from django.contrib.auth import authenticate, login as dj_login, logout as dj_logout, update_session_auth_hash
from rest_framework.authtoken.models import Token
from django import forms
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from openpyxl import Workbook, load_workbook
from .models import *
from .people import login_name, teacher_rooms


def next_school_day(today=None):
    """Tomorrow; when tomorrow is Sunday, Monday."""
    d = (today or timezone.localdate()) + timedelta(days=1)
    return d + timedelta(days=1) if d.weekday() == 6 else d


def purge_diary():
    """Diary is kept for 3 days (today + 2 days before); older entries are removed automatically."""
    Diary.objects.filter(date__lt=timezone.localdate() - timedelta(days=2)).delete()


def panel(view):
    @wraps(view)
    def w(request, *a, **k):
        u = request.user
        if not u.is_authenticated:
            return redirect("panel-login")
        bad = None
        if u.role != "SUPER_ADMIN" and not (u.school and u.school.is_valid()):
            bad = "Your school is inactive or its subscription has expired"
        if u.role == "PARENT" and not Student.objects.filter(parent=u).exists():
            bad = "This account has been deleted. Please contact the school office"
        if bad:
            dj_logout(request); messages.error(request, bad)
            return redirect("panel-login")
        return view(request, *a, **k)
    return w


ROLE_MAP = {"ADMIN": "SCHOOL_ADMIN", "TEACHER": "TEACHER", "PARENT": "PARENT", "SUPER_ADMIN": "SUPER_ADMIN"}


WHO = {"super": ("SUPER_ADMIN", "Super Admin"), "admin": ("ADMIN", "School Admin"),
       "teacher": ("TEACHER", "Teacher"), "student": ("PARENT", "Student / Parent")}


def login_page(request, who=None):
    if request.user.is_authenticated:
        return redirect("panel-home")
    if request.method == "POST":
        p = request.POST
        name = login_name(p.get("username"))
        u = authenticate(request, username=name, password=p.get("password"))
        if not u:
            x = User.objects.filter(username=name).first()
            if x and not x.is_active and x.check_password(p.get("password") or ""):
                messages.error(request, "Your account is inactive. Please contact your admin")
            else:
                messages.error(request, "Incorrect ID card / login ID or password")
        elif u.role == "PARENT" and not Student.objects.filter(parent=u).exists():
            messages.error(request, "This account has been deleted. Please contact the school office")
        elif ROLE_MAP.get(p.get("role")) not in (None, u.role):
            messages.error(request, "This account does not belong to the selected role. Please choose the correct role")
        else:
            dj_login(request, u)
            return redirect("panel-home")
    ctx = {"role": WHO[who][0], "title": WHO[who][1] + " Login", "fixed": True} if who in WHO else {}
    ctx["idlabel"] = "Father ID card (CNIC)" if ctx.get("role") == "PARENT" else ("Login ID" if ctx.get("role") else "Login ID / Father ID card (CNIC)")
    return render(request, "panel/login.html", ctx)


def logout_page(request):
    dj_logout(request)
    return redirect("panel-login")


@panel
def home(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return render(request, "panel/super.html", {
            "brand": Branding.get(),
            "schools": School.objects.order_by("-id"),
            "admins": User.objects.filter(role="SCHOOL_ADMIN").select_related("school").order_by("school__name"),
            "codes": ActivationCode.objects.filter(used_at__isnull=True).select_related("school")})
    from .pages import home_page
    return home_page(request)


# ----- Super admin -----
def _super_post(request):
    return request.user.role == "SUPER_ADMIN" and request.method == "POST"


@panel
def school_add(request):
    if _super_post(request):
        p = request.POST
        try:
            School.objects.create(name=p["name"], expires_on=p["expires_on"], max_students=int(p.get("max_students") or 500))
            messages.success(request, "School created. Now click 'New code'.")
        except Exception as e:
            messages.error(request, str(e))
    return redirect("panel-home")


@panel
def school_code(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        code = "SCH-%s-%s" % (secrets.token_hex(2).upper(), secrets.token_hex(2).upper())
        ActivationCode.objects.create(code=code, school=s)
        messages.success(request, f"Activation code for {s.name}: {code}")
    return redirect("panel-home")


@panel
def school_extend(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        try:
            s.expires_on = request.POST["expires_on"]; s.save()
            messages.success(request, f"Expiry updated for {s.name}")
        except Exception as e:
            messages.error(request, str(e))
    return redirect("panel-home")


def activate_page(request):
    if request.method == "POST":
        p = request.POST
        code = ActivationCode.objects.select_related("school").filter(
            code=p.get("code", "").strip().upper(), used_at__isnull=True).first()
        err = None
        if not code:
            err = "Invalid code, or it has already been used"
        elif code.school.expires_on < date.today():
            err = "This code has expired"
        elif not p.get("username") or not p.get("password"):
            err = "Enter a username and password"
        elif User.objects.filter(username=p["username"]).exists():
            err = "This username already exists, please choose another"
        if err:
            messages.error(request, err)
        else:
            with transaction.atomic():
                u = User.objects.create_user(username=p["username"], password=p["password"],
                                             first_name=p.get("full_name", ""), role="SCHOOL_ADMIN", school=code.school)
                code.used_at = timezone.now(); code.save()
                code.school.is_active = True; code.school.save()
            dj_login(request, u)
            messages.success(request, "School activated. You are now logged in.")
            return redirect("panel-home")
    return render(request, "panel/activate.html")


# ----- Users: create / active / password -----
def _back(request, default="panel-home"):
    nxt = request.POST.get("next", "")
    return redirect(nxt) if nxt.startswith("/panel/") else redirect(default)


def _can_manage(u, t):
    if u.role == "SUPER_ADMIN":
        return t.role == "SCHOOL_ADMIN"
    return u.role == "SCHOOL_ADMIN" and t.school_id == u.school_id and t.role in ("TEACHER", "PARENT")


@panel
def user_add(request):
    u, p = request.user, request.POST
    if request.method == "POST":
        try:
            if u.role == "SUPER_ADMIN":
                school, role = get_object_or_404(School, pk=p.get("school")), "SCHOOL_ADMIN"
                school.is_active = True; school.save()
            elif u.role == "SCHOOL_ADMIN":
                school, role = u.school, p.get("role")
                if role != "TEACHER":
                    raise ValueError("Only teacher accounts are created here. Parent accounts are created from the Students page (father ID card).")
            else:
                raise ValueError("Not allowed")
            if not p.get("username") or not p.get("password"):
                raise ValueError("Enter a username and password")
            if User.objects.filter(username=p["username"]).exists():
                raise ValueError("This username already exists")
            User.objects.create_user(username=p["username"], password=p["password"], first_name=p.get("full_name", ""),
                                     role=role, school=school, phone=p.get("phone", ""))
            messages.success(request, "Account created")
        except Exception as e:
            messages.error(request, str(e))
    return _back(request)


@panel
def user_toggle(request, pk):
    t = get_object_or_404(User, pk=pk)
    if request.method == "POST" and _can_manage(request.user, t):
        t.is_active = not t.is_active; t.save()
        if not t.is_active:
            Token.objects.filter(user=t).delete()
        messages.success(request, f"{t.first_name or t.username} is now {'Active' if t.is_active else 'Inactive'}")
    return _back(request)


@panel
def user_password(request, pk):
    t = get_object_or_404(User, pk=pk)
    if request.method == "POST" and _can_manage(request.user, t):
        pw = request.POST.get("password", "")
        if len(pw) < 4:
            messages.error(request, "Password must be at least 4 characters")
        else:
            t.set_password(pw); t.save(); Token.objects.filter(user=t).delete()
            messages.success(request, f"Password changed for {t.first_name or t.username}")
    return _back(request)


@panel
def school_edit(request, pk):
    if request.user.role != "SUPER_ADMIN":
        return redirect("panel-home")
    s = get_object_or_404(School, pk=pk)
    if request.method == "POST":
        p = request.POST
        try:
            s.name = p["name"].strip() or s.name
            s.expires_on = p["expires_on"]
            s.max_students = int(p.get("max_students") or 500)
            s.save()
            messages.success(request, "School saved")
            return redirect("panel-home")
        except Exception as e:
            messages.error(request, str(e))
    return render(request, "panel/school_edit.html", {"s": s})


@panel
def school_delete(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        if request.POST.get("confirm", "").strip().upper() != "DELETE":
            messages.error(request, "Nothing deleted. Type DELETE to confirm.")
            return redirect("panel-school-edit", pk=pk)
        for d in Document.objects.filter(school=s):
            d.file.delete(save=False)
        name = s.name
        User.objects.filter(school=s).delete()
        s.delete()
        messages.success(request, f"School '{name}' and all its data were deleted")
    return redirect("panel-home")


@panel
def user_edit(request, pk):
    t = get_object_or_404(User, pk=pk)
    u = request.user
    if not _can_manage(u, t) or t.role == "PARENT":
        messages.error(request, "Parent accounts follow the father CNIC. Change it on the Students page.")
        return redirect("panel-home")
    back = "/panel/" if u.role == "SUPER_ADMIN" else "/panel/accounts/?tab=teachers"
    if request.method == "POST":
        p = request.POST
        login = p.get("username", "").strip()
        if not login:
            messages.error(request, "Login ID is required")
        elif User.objects.filter(username=login).exclude(pk=t.pk).exists():
            messages.error(request, "This login ID is already used")
        else:
            t.first_name, t.username, t.phone = p.get("full_name", "").strip(), login, p.get("phone", "").strip()
            t.save()
            messages.success(request, "Account saved")
            return redirect(back)
    return render(request, "panel/user_edit.html", {"t": t, "back": back})


@panel
def user_delete(request, pk):
    t = get_object_or_404(User, pk=pk)
    if request.method == "POST" and _can_manage(request.user, t):
        nm = t.first_name or t.username
        t.delete()
        messages.success(request, f"{nm} deleted")
    return _back(request)


@panel
def school_toggle(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        s.is_active = not s.is_active; s.save()
        messages.success(request, f"{s.name} is now {'Active' if s.is_active else 'Inactive'}")
    return redirect("panel-home")


@panel
def my_password(request):
    if request.method == "POST":
        u, p = request.user, request.POST
        if not u.check_password(p.get("old", "")):
            messages.error(request, "Old password is incorrect")
        elif len(p.get("new", "")) < 4:
            messages.error(request, "New password must be at least 4 characters")
        else:
            u.set_password(p["new"]); u.save(); update_session_auth_hash(request, u)
            messages.success(request, "Password changed")
            return redirect("panel-home")
    return render(request, "panel/password.html")


@panel
def attendance_page(request):
    u = request.user
    if u.role not in ("SCHOOL_ADMIN", "TEACHER"):
        return redirect("panel-home")
    cid = request.GET.get("class") or request.POST.get("class")
    day = request.GET.get("date") or request.POST.get("date") or str(date.today())
    students = []
    classes = teacher_rooms(u) if u.role == "TEACHER" else ClassRoom.objects.filter(school=u.school)
    if cid and not classes.filter(pk=cid).exists():
        cid = None
    if cid:
        students = list(Student.objects.filter(school=u.school, classroom_id=cid).order_by("roll_no"))
        if request.method == "POST":
            for st in students:
                v = request.POST.get(f"s{st.id}")
                if v in ("P", "A", "L"):
                    Attendance.objects.update_or_create(student=st, date=day, defaults={"status": v, "marked_by": u})
            messages.success(request, "Attendance saved")
        cur = {a.student_id: a.status for a in Attendance.objects.filter(student__in=students, date=day)}
        for st in students:
            st.cur = cur.get(st.id, "P")
    return render(request, "panel/attendance.html", {
        "classes": classes, "cid": str(cid or ""), "day": day, "students": students})


@panel
def diary_add(request):
    u, p = request.user, request.POST
    if request.method == "POST" and u.role in ("TEACHER", "SCHOOL_ADMIN"):
        allowed = teacher_rooms(u) if u.role == "TEACHER" else ClassRoom.objects.filter(school=u.school)
        room = allowed.filter(pk=p.get("classroom") or 0).first()
        if room and p.get("text"):
            try:
                when = date.fromisoformat((p.get("date") or "")[:10])
            except ValueError:
                when = next_school_day()
            Diary.objects.create(school=u.school, classroom=room, teacher=u, subject=p.get("subject", ""), text=p["text"], date=when)
            messages.success(request, "Diary saved")
        else:
            messages.error(request, "Choose a class and write the diary")
    return redirect("panel-home")


# ----- Generic module manager (add / edit / delete) -----
ADM, TCH = ("SCHOOL_ADMIN",), ("SCHOOL_ADMIN", "TEACHER")
MODS = {
    "classes": dict(model=ClassRoom, title="Classes", roles=ADM, sp="school", fields=["name", "class_teacher"], cols=["name", "class_teacher"]),
    "diary": dict(model=Diary, title="Diary", roles=TCH, sp="school", own="teacher", stamp=["teacher"], fields=["classroom", "subject", "text", "date"], cols=["date", "classroom", "subject", "text"]),
    "notices": dict(model=Notice, title="Notice Board", roles=ADM, sp="school", stamp=["posted_by"], fields=["title", "body", "date"], cols=["date", "title", "body"]),
    "timetable": dict(model=Timetable, title="Timetable (day: 1=Mon ... 7=Sun)", roles=ADM, sp="school", fields=["classroom", "day", "period", "subject", "teacher", "start_time", "end_time"], cols=["classroom", "day", "period", "subject", "teacher", "start_time", "end_time"]),
    "datesheet": dict(model=DateSheet, title="Date Sheet", roles=ADM, sp="school", fields=["classroom", "exam_name", "subject", "date", "start_time", "note"], cols=["date", "classroom", "exam_name", "subject", "start_time"]),
    "lessonplans": dict(model=LessonPlan, title="Lesson Plans", roles=TCH, sp="school", own="teacher", stamp=["teacher"], fields=["classroom", "subject", "topic", "plan", "date"], cols=["date", "classroom", "subject", "topic"]),
}


def _cfg(request, key):
    cfg = MODS.get(key)
    return cfg if cfg and request.user.role in cfg["roles"] else None


def _scoped(cfg, u):
    qs = cfg["model"].objects.filter(**{cfg["sp"]: u.school})
    if u.role == "TEACHER" and cfg.get("own"):
        qs = qs.filter(**{cfg["own"]: u})
    if u.role == "TEACHER" and any(f.name == "classroom" for f in cfg["model"]._meta.get_fields()):
        qs = qs.filter(classroom__in=teacher_rooms(u))
    return qs


def _form(cfg, u, data=None, inst=None):
    f = forms.modelform_factory(cfg["model"], fields=cfg["fields"])(data, instance=inst)
    for name, fld in f.fields.items():
        qs = getattr(fld, "queryset", None)
        if qs is not None and hasattr(qs.model, "school"):
            qs = qs.filter(school=u.school)
            if name in ("teacher", "class_teacher"):
                qs = qs.filter(role="TEACHER")
            if name == "classroom" and u.role == "TEACHER":
                qs = qs.filter(pk__in=teacher_rooms(u))
            if name == "parent":
                qs = qs.filter(role="PARENT")
                fld.label_from_instance = lambda x: f"{x.first_name} ({x.username})" if x.first_name else x.username
            fld.queryset = qs
    return f


def _cell(o, c):
    v = getattr(o, c)
    if c == "date" and isinstance(o, Diary) and v:
        return v.strftime("%a, %d %b %Y")
    return "" if v is None else str(v)


@panel
def mod_list(request, key):
    cfg = _cfg(request, key)
    if not cfg:
        return redirect("panel-home")
    if key == "diary":
        purge_diary()
    rows = [{"pk": o.pk, "cells": [_cell(o, c) for c in cfg["cols"]]} for o in _scoped(cfg, request.user)[:500]]
    return render(request, "panel/module.html", {"key": key, "title": cfg["title"],
                  "cols": [c.replace("_", " ").title() for c in cfg["cols"]], "rows": rows,
                  "pdfs": Document.objects.filter(school=request.user.school, kind=("notice" if key == "notices" else "datesheet")).select_related("classroom") if key in ("datesheet", "notices") else None,
                  "classes": ClassRoom.objects.filter(school=request.user.school) if key in ("datesheet", "notices") else None})


@panel
def mod_form(request, key, pk=None):
    cfg, u = _cfg(request, key), request.user
    if not cfg:
        return redirect("panel-home")
    inst = get_object_or_404(_scoped(cfg, u), pk=pk) if pk else None
    f = _form(cfg, u, request.POST or None, inst)
    if key == "diary" and "date" in f.fields:  # new diary: tomorrow (Monday if tomorrow is Sunday), but any date can be chosen
        f.fields["date"].widget = forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")
        if not inst:
            f.fields["date"].initial = next_school_day()
    if request.method == "POST" and f.is_valid():
        o = f.save(commit=False)
        if hasattr(cfg["model"], "school"):
            o.school = u.school
        if not inst:
            for k in cfg.get("stamp", []):
                setattr(o, k, u)
        o.save()
        messages.success(request, "Saved")
        return redirect("panel-mod", key=key)
    return render(request, "panel/form.html", {"form": f, "key": key, "title": cfg["title"]})


@panel
def mod_delete(request, key, pk):
    cfg = _cfg(request, key)
    if cfg and request.method == "POST":
        get_object_or_404(_scoped(cfg, request.user), pk=pk).delete()
        messages.success(request, "Deleted")
    return redirect("panel-mod", key=key) if cfg else redirect("panel-home")


# ----- Excel upload inside every module -----
KEYS = {"classes": ["name"], "timetable": ["classroom", "day", "period"], "datesheet": ["classroom", "exam_name", "subject"]}


def _cell_val(field, raw, u):
    from django.db.models import ForeignKey, DateField
    s = "" if raw is None else str(raw).strip()
    if s.endswith(".0"):
        s = s[:-2]
    if isinstance(field, ForeignKey):
        if not s:
            return None
        if field.related_model is ClassRoom:
            for c in (teacher_rooms(u) if u.role == "TEACHER" else ClassRoom.objects.filter(school=u.school)):
                if s.lower() in (str(c).lower(), c.name.lower()):
                    return c
            raise ValueError(f"class '{s}' not found" + (" (or not assigned to you)" if u.role == "TEACHER" else ""))
        if field.related_model is User:
            x = User.objects.filter(school=u.school, role="TEACHER").filter(Q(first_name__iexact=s) | Q(username__iexact=s)).first()
            if not x:
                raise ValueError(f"teacher '{s}' not found")
            return x
        raise ValueError(f"cannot import {field.name}")
    if isinstance(field, DateField):
        if hasattr(raw, "date"):
            return raw.date()
        return date.fromisoformat(s[:10]) if s else date.today()
    if s == "" and field.has_default():
        return field.get_default()
    return field.to_python(s)


@panel
def mod_template(request, key):
    cfg = _cfg(request, key)
    if not cfg:
        return redirect("panel-home")
    wb = Workbook(); wb.active.append(cfg["fields"])
    resp = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = f'attachment; filename="{key}_template.xlsx"'
    wb.save(resp)
    return resp


@panel
def mod_import(request, key):
    cfg, u, f = _cfg(request, key), request.user, request.FILES.get("file")
    if key in ("notices", "diary"):  # notices take text or a PDF, diary is typed: no Excel
        return redirect("panel-mod", key=key) if cfg else redirect("panel-home")
    if not cfg or request.method != "POST" or not f:
        messages.error(request, "Choose an Excel (.xlsx) file")
        return redirect("panel-mod", key=key) if cfg else redirect("panel-home")
    model, ok, errs = cfg["model"], 0, []
    fields = {fl.name: fl for fl in model._meta.get_fields() if fl.name in cfg["fields"]}
    try:
        it = load_workbook(f, data_only=True).active.iter_rows(values_only=True)
        head = [("" if h is None else str(h).strip().lower().replace(" ", "_")) for h in next(it)]
        for n, r in enumerate(it, start=2):
            if not any(c not in (None, "") for c in r):
                continue
            try:
                with transaction.atomic():
                    row = dict(zip(head, r))
                    vals = {name: _cell_val(fl, row.get(name), u) for name, fl in fields.items() if name in row}
                    obj = None
                    if key in KEYS and all(k in vals for k in KEYS[key]):
                        obj = _scoped(cfg, u).filter(**{k: vals[k] for k in KEYS[key]}).first()
                    if obj is None:
                        obj = model()
                        if hasattr(model, "school"):
                            obj.school = u.school
                        for k in cfg.get("stamp", []):
                            setattr(obj, k, u)
                    for k, v in vals.items():
                        setattr(obj, k, v)
                    obj.full_clean(exclude=[x for x in ("school",) + tuple(cfg.get("stamp", []))])
                    obj.save(); ok += 1
            except Exception as e:
                errs.append(f"Row {n}: {getattr(e, 'message_dict', e)}")
    except Exception as e:
        errs.append(f"Could not read the file (it must be .xlsx): {e}")
    messages.success(request, f"{ok} row(s) saved")
    for e in errs[:10]:
        messages.warning(request, e)
    return redirect("panel-mod", key=key)


# ----- Leaves -----
def _can_review(u, lv):
    return (lv.status == "P" and lv.applicant_id != u.id and
            (u.role == "SCHOOL_ADMIN" or (u.role == "TEACHER" and lv.kind == "STUDENT" and lv.student_id and
                                          teacher_rooms(u).filter(pk=lv.student.classroom_id).exists())))


@panel
def leaves_page(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    qs = Leave.objects.filter(school=u.school).select_related("student", "applicant").order_by("-id")
    if u.role == "PARENT":
        qs = qs.filter(applicant=u)
    elif u.role == "TEACHER":
        qs = qs.filter(Q(kind="STUDENT", student__classroom__in=teacher_rooms(u)) | Q(applicant=u))
    rows = list(qs[:200])
    for lv in rows:
        lv.can_review = _can_review(u, lv)
    kids = Student.objects.filter(school=u.school, parent=u) if u.role == "PARENT" else []
    return render(request, "panel/leaves.html", {"rows": rows, "kids": kids})


@panel
def leave_apply(request):
    u, p = request.user, request.POST
    if request.method == "POST" and u.role in ("PARENT", "TEACHER"):
        try:
            if u.role == "PARENT":
                st = Student.objects.filter(school=u.school, parent=u, pk=p.get("student") or 0).first()
                if not st:
                    raise ValueError("Choose your child")
                kw = dict(kind="STUDENT", student=st)
            else:
                kw = dict(kind="STAFF")
            Leave.objects.create(school=u.school, applicant=u, from_date=p["from_date"], to_date=p["to_date"],
                                 reason=p.get("reason", ""), **kw)
            messages.success(request, "Leave request sent")
        except Exception as e:
            messages.error(request, f"Could not create leave: {e}")
    return redirect("panel-leaves")


@panel
def leave_review(request, pk):
    u = request.user
    lv = get_object_or_404(Leave, pk=pk, school=u.school) if u.school else None
    if lv and request.method == "POST" and _can_review(u, lv) and request.POST.get("status") in ("A", "R"):
        lv.status, lv.remark, lv.reviewed_by = request.POST["status"], request.POST.get("remark", ""), u
        lv.save()
        messages.success(request, "Leave updated")
    return redirect("panel-leaves")


# ----- Branding (Super admin) -----
@panel
def branding_save(request):
    if not _super_post(request):
        return redirect("panel-home")
    b, p = Branding.get(), request.POST
    if p.get("app_name", "").strip():
        b.app_name = p["app_name"].strip()[:100]
    if re.fullmatch(r"#[0-9a-fA-F]{6}", p.get("primary_color", "")):
        b.primary_color = p["primary_color"]
    f = request.FILES.get("logo")
    if p.get("remove_logo"):
        b.logo_b64 = b.logo_mime = ""
    elif f:
        if f.size > 200 * 1024 or f.content_type not in ("image/png", "image/jpeg", "image/webp"):
            messages.error(request, "Logo must be PNG/JPG and smaller than 200 KB")
        else:
            b.logo_b64, b.logo_mime = base64.b64encode(f.read()).decode(), f.content_type
    b.save()
    messages.success(request, "Branding saved")
    return redirect("panel-home")


@panel
def leave_delete(request, pk):
    """The school admin can delete any leave of his school for good (one, or all with pk=0)."""
    u = request.user
    if request.method == "POST" and u.role == "SCHOOL_ADMIN":
        qs = Leave.objects.filter(school=u.school)
        n = qs.delete()[0] if pk == 0 else get_object_or_404(qs, pk=pk).delete()[0]
        messages.success(request, "Deleted")
    return redirect("panel-leaves")
