import base64
import re
import secrets
from datetime import date
from django.utils import timezone
from decimal import Decimal
from functools import wraps
from django.contrib import messages
from django.contrib.auth import authenticate, login as dj_login, logout as dj_logout, update_session_auth_hash
from rest_framework.authtoken.models import Token
from django import forms
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from openpyxl import Workbook, load_workbook
from .models import *


def panel(view):
    @wraps(view)
    def w(request, *a, **k):
        u = request.user
        if not u.is_authenticated:
            return redirect("panel-login")
        bad = None
        if u.role != "SUPER_ADMIN" and not (u.school and u.school.is_valid()):
            bad = "Your school is inactive or its subscription has expired"
        if bad:
            dj_logout(request); messages.error(request, bad)
            return redirect("panel-login")
        return view(request, *a, **k)
    return w


ROLE_MAP = {"ADMIN": "SCHOOL_ADMIN", "TEACHER": "TEACHER", "PARENT": "PARENT", "SUPER_ADMIN": "SUPER_ADMIN"}


WHO = {"super": ("SUPER_ADMIN", "Super Admin"), "admin": ("ADMIN", "School Admin"),
       "teacher": ("TEACHER", "Teacher"), "student": ("PARENT", "Student / Parent")}


def login_page(request, who=None):
    if request.user.is_authenticated:
        return redirect("panel-home")
    if request.method == "POST":
        p = request.POST
        u = authenticate(request, username=p.get("username"), password=p.get("password"))
        if not u:
            x = User.objects.filter(username=p.get("username")).first()
            if x and not x.is_active and x.check_password(p.get("password") or ""):
                messages.error(request, "Your account is inactive. Please contact your admin")
            else:
                messages.error(request, "Incorrect username or password")
        elif ROLE_MAP.get(p.get("role")) not in (None, u.role):
            messages.error(request, "This account does not belong to the selected role. Please choose the correct role")
        else:
            dj_login(request, u)
            return redirect("panel-home")
    ctx = {"role": WHO[who][0], "title": WHO[who][1] + " Login"} if who in WHO else {}
    return render(request, "panel/login.html", ctx)


def logout_page(request):
    dj_logout(request)
    return redirect("panel-login")


@panel
def home(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return render(request, "panel/super.html", {
            "schools": School.objects.order_by("-id"),
            "admins": User.objects.filter(role="SCHOOL_ADMIN").select_related("school").order_by("school__name"),
            "codes": ActivationCode.objects.filter(used_at__isnull=True).select_related("school")})
    from .pages import home_page
    return home_page(request)


# ----- Super admin -----
def _super_post(request):
    return request.user.role == "SUPER_ADMIN" and request.method == "POST"


@panel
def school_add(request):
    if _super_post(request):
        p = request.POST
        try:
            School.objects.create(name=p["name"], expires_on=p["expires_on"], max_students=int(p.get("max_students") or 500))
            messages.success(request, "School created. Now click 'New code'.")
        except Exception as e:
            messages.error(request, str(e))
    return redirect("panel-home")


@panel
def school_code(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        code = "SCH-%s-%s" % (secrets.token_hex(2).upper(), secrets.token_hex(2).upper())
        ActivationCode.objects.create(code=code, school=s)
        messages.success(request, f"Activation code for {s.name}: {code}")
    return redirect("panel-home")


@panel
def school_extend(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        try:
            s.expires_on = request.POST["expires_on"]; s.save()
            messages.success(request, f"Expiry updated for {s.name}")
        except Exception as e:
            messages.error(request, str(e))
    return redirect("panel-home")


# ----- Excel helpers -----
def t(v):
    s = "" if v is None else str(v).strip()
    return s[:-2] if s.endswith(".0") else s


def rows(f):
    it = load_workbook(f, data_only=True).active.iter_rows(values_only=True)
    head = [t(h).lower() for h in next(it)]
    for n, r in enumerate(it, start=2):
        if any(c not in (None, "") for c in r):
            yield n, dict(zip(head, r))


def report(request, ok, errs, what, skipped=()):
    messages.success(request, f"{ok} {what} saved/updated")
    if skipped:
        messages.warning(request, f"{len(skipped)} row(s) skipped, nothing saved, because the student is not added yet: "
                         + "; ".join(skipped[:10]) + (" ..." if len(skipped) > 10 else ""))
    for e in errs[:15]:
        messages.warning(request, e)
    if len(errs) > 15:
        messages.warning(request, f"...and {len(errs) - 15} more errors")


def xlsx(name, head, data=()):
    wb = Workbook(); ws = wb.active; ws.append(head)
    for r in data:
        ws.append(r)
    resp = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = f'attachment; filename="{name}"'
    wb.save(resp)
    return resp


def _admin_upload(request):
    return request.user.role == "SCHOOL_ADMIN" and request.method == "POST" and request.FILES.get("file")


@panel
def import_students(request):
    if not _admin_upload(request):
        return redirect("panel-home")
    s, ok, errs = request.user.school, 0, []
    only_class = t(request.POST.get("class"))
    try:
        for n, r in rows(request.FILES["file"]):
            try:
                with transaction.atomic():
                    name, roll, cls = t(r.get("name")), t(r.get("roll_no")), t(r.get("class"))
                    if only_class and not cls:
                        cls = only_class
                    if not (name and roll and cls):
                        raise ValueError("name, roll_no and class are required")
                    room, _ = ClassRoom.objects.get_or_create(school=s, name=cls, section=t(r.get("section")))
                    cn = t(r.get("father_cnic")).replace("-", "")
                    parent = None
                    if cn:  # father CNIC = parent login; same CNIC -> same account
                        parent = User.objects.filter(username=cn).first()
                        if parent and (parent.school_id != s.id or parent.role != "PARENT"):
                            raise ValueError(f"father CNIC '{cn}' already belongs to someone else")
                        if not parent:
                            parent = User.objects.create_user(
                                username=cn, password=t(r.get("father_password")) or secrets.token_urlsafe(6),
                                first_name=t(r.get("father_name")), role="PARENT", school=s, phone=t(r.get("phone")))
                    else:
                        pu = t(r.get("parent_username"))
                        if pu:
                            parent = User.objects.filter(username=pu).first()
                            if parent and (parent.school_id != s.id or parent.role != "PARENT"):
                                raise ValueError(f"username '{pu}' already belongs to someone else")
                            if not parent:
                                parent = User.objects.create_user(
                                    username=pu, password=t(r.get("parent_password")) or secrets.token_urlsafe(6),
                                    first_name=t(r.get("parent_name")), role="PARENT", school=s, phone=t(r.get("phone")))
                    st = Student.objects.filter(school=s, classroom=room, roll_no=roll).first()
                    if not st:
                        if Student.objects.filter(school=s).count() >= s.max_students:
                            raise ValueError("Maximum student limit reached")
                        st = Student(school=s, classroom=room, roll_no=roll)
                    st.name, st.phone, st.father_cnic = name, t(r.get("phone")), cn
                    if parent:
                        st.parent = parent
                    st.save(); ok += 1
            except Exception as e:
                errs.append(f"Row {n}: {e}")
    except Exception as e:
        errs.append(f"Could not read the file (it must be .xlsx): {e}")
    report(request, ok, errs, "students")
    return redirect("panel-home")


ID_KEYS = ("roll_no", "student_id", "student id", "roll no", "rollno", "id", "admission_no", "admission no", "reg_no", "gr_no")
FIXED = set(ID_KEYS) | {"class", "section", "exam_name", "total_marks", "name", "student_name", "student name"}


class Skip(Exception):
    """Row skipped on purpose (the student is not added yet): nothing is saved for it."""


def _cls(v):
    s = t(v).lower()
    return s[6:].strip() if s.startswith("class ") else s


def find_student(s, r):
    """The ID in the sheet must belong to a student who is already added. Otherwise the row is skipped."""
    rid = next((t(r.get(k)) for k in ID_KEYS if t(r.get(k))), "")
    if not rid:
        raise ValueError("student ID (roll_no) is empty")
    ids = {rid, rid.lstrip("0") or "0"} if rid.isdigit() else {rid}
    found = list(Student.objects.filter(school=s, roll_no__in=ids).select_related("classroom"))
    cls, sec = _cls(r.get("class")), t(r.get("section")).lower()
    if cls:
        found = [x for x in found if x.classroom and _cls(x.classroom.name) == cls]
    if sec:
        found = [x for x in found if x.classroom and x.classroom.section.lower() == sec]
    if not found:
        raise Skip(f"student ID {rid} is not added yet")
    if len(found) > 1:
        raise Skip(f"more than one student has ID {rid} (add class and section)")
    return found[0]


@panel
def import_marks(request):
    if not _admin_upload(request):
        return redirect("panel-home")
    s, ok, errs, skipped = request.user.school, 0, [], []
    only_class = t(request.POST.get("class"))
    try:
        for n, r in rows(request.FILES["file"]):
            try:
                with transaction.atomic():
                    if only_class:
                        r = {**r, "class": only_class}
                    st = find_student(s, r)
                    exam = t(r.get("exam_name"))
                    if not exam:
                        raise ValueError("exam_name is empty")
                    total = int(float(t(r.get("total_marks")) or 100))
                    for subj, val in r.items():
                        if not subj or subj in FIXED or val in (None, ""):
                            continue
                        Mark.objects.update_or_create(student=st, exam_name=exam, subject=subj.title(),
                                                      defaults={"total": total, "obtained": Decimal(t(val))})
                        ok += 1
            except Skip as e:
                skipped.append(f"Row {n}: {e}")
            except Exception as e:
                errs.append(f"Row {n}: {e}")
    except Exception as e:
        errs.append(f"Could not read the file (it must be .xlsx): {e}")
    report(request, ok, errs, "marks entries", skipped)
    return redirect("panel-home")


SH = ["roll_no", "name", "class", "section", "phone", "father_cnic", "father_name", "father_password"]
MH = ["roll_no", "class", "section", "exam_name", "total_marks", "Math", "English", "Urdu"]


@panel
def template(request, kind):
    if request.user.role not in ("SCHOOL_ADMIN", "SUPER_ADMIN"):
        return redirect("panel-home")
    if kind == "fees":
        return xlsx("fees_template.xlsx", ["roll_no", "class", "section", "title", "amount", "due_date", "paid_amount"],
                    [[1, "5", "A", "Nov Fee", 1500, "2026-11-10", 0]])
    if kind == "students":
        return xlsx("students_template.xlsx", SH, [[1, "Ali Khan", "5", "A", "03001234567", "3210212345671", "Khan Sahib", "pass123"]])
    return xlsx("marks_template.xlsx", MH, [[1, "5", "A", "Mid Term", 100, 78, 85, 90]])


@panel
def export(request, kind):
    if request.user.role != "SCHOOL_ADMIN":
        return redirect("panel-home")
    s = request.user.school
    if kind == "students":
        q = Student.objects.filter(school=s).select_related("classroom", "parent").order_by("classroom__name", "roll_no")
        return xlsx("students.xlsx", ["roll_no", "name", "class", "section", "phone", "father_cnic", "father_name", "parent_login"],
                    [[x.roll_no, x.name, x.classroom.name if x.classroom else "",
                      x.classroom.section if x.classroom else "", x.phone, x.father_cnic,
                      x.parent.first_name if x.parent else "", x.parent.username if x.parent else ""] for x in q])
    q = Mark.objects.filter(student__school=s).select_related("student__classroom").order_by("student__classroom__name", "student__roll_no")
    return xlsx("results.xlsx", ["roll_no", "name", "class", "section", "exam_name", "subject", "total", "obtained", "percentage"],
                [[m.student.roll_no, m.student.name, m.student.classroom.name if m.student.classroom else "",
                  m.student.classroom.section if m.student.classroom else "", m.exam_name, m.subject, m.total,
                  float(m.obtained), m.percentage] for m in q])


def activate_page(request):
    if request.method == "POST":
        p = request.POST
        code = ActivationCode.objects.select_related("school").filter(
            code=p.get("code", "").strip().upper(), used_at__isnull=True).first()
        err = None
        if not code:
            err = "Invalid code, or it has already been used"
        elif code.school.expires_on < date.today():
            err = "This code has expired"
        elif not p.get("username") or not p.get("password"):
            err = "Enter a username and password"
        elif User.objects.filter(username=p["username"]).exists():
            err = "This username already exists, please choose another"
        if err:
            messages.error(request, err)
        else:
            with transaction.atomic():
                u = User.objects.create_user(username=p["username"], password=p["password"],
                                             first_name=p.get("full_name", ""), role="SCHOOL_ADMIN", school=code.school)
                code.used_at = timezone.now(); code.save()
                code.school.is_active = True; code.school.save()
            dj_login(request, u)
            messages.success(request, "School activated. You are now logged in.")
            return redirect("panel-home")
    return render(request, "panel/activate.html")


# ----- Users: create / active / password -----
def _can_manage(u, t):
    if u.role == "SUPER_ADMIN":
        return t.role == "SCHOOL_ADMIN"
    return u.role == "SCHOOL_ADMIN" and t.school_id == u.school_id and t.role in ("TEACHER", "PARENT")


@panel
def user_add(request):
    u, p = request.user, request.POST
    if request.method == "POST":
        try:
            if u.role == "SUPER_ADMIN":
                school, role = get_object_or_404(School, pk=p.get("school")), "SCHOOL_ADMIN"
                school.is_active = True; school.save()
            elif u.role == "SCHOOL_ADMIN":
                school, role = u.school, p.get("role")
                if role not in ("TEACHER", "PARENT"):
                    raise ValueError("Choose a role: Teacher or Student/Parent")
            else:
                raise ValueError("Not allowed")
            if not p.get("username") or not p.get("password"):
                raise ValueError("Enter a username and password")
            if User.objects.filter(username=p["username"]).exists():
                raise ValueError("This username already exists")
            nu = User.objects.create_user(username=p["username"], password=p["password"], first_name=p.get("full_name", ""),
                                          role=role, school=school, phone=p.get("phone", ""))
            if role == "TEACHER" and p.get("classroom"):
                room = ClassRoom.objects.filter(school=school, pk=p["classroom"]).first()
                if room:
                    room.class_teacher = nu
                    room.save()
            messages.success(request, "Account created")
        except Exception as e:
            messages.error(request, str(e))
    return redirect("panel-home")


@panel
def user_toggle(request, pk):
    t = get_object_or_404(User, pk=pk)
    if request.method == "POST" and _can_manage(request.user, t):
        t.is_active = not t.is_active; t.save()
        if not t.is_active:
            Token.objects.filter(user=t).delete()
        messages.success(request, f"{t.username} is now {'Active' if t.is_active else 'Inactive'}")
    return redirect("panel-home")


@panel
def user_password(request, pk):
    t = get_object_or_404(User, pk=pk)
    if request.method == "POST" and _can_manage(request.user, t):
        pw = request.POST.get("password", "")
        if len(pw) < 4:
            messages.error(request, "Password must be at least 4 characters")
        else:
            t.set_password(pw); t.save(); Token.objects.filter(user=t).delete()
            messages.success(request, f"Password changed for {t.username}")
    return redirect("panel-home")


@panel
def school_toggle(request, pk):
    if _super_post(request):
        s = get_object_or_404(School, pk=pk)
        s.is_active = not s.is_active; s.save()
        messages.success(request, f"{s.name} is now {'Active' if s.is_active else 'Inactive'}")
    return redirect("panel-home")


@panel
def my_password(request):
    if request.method == "POST":
        u, p = request.user, request.POST
        if not u.check_password(p.get("old", "")):
            messages.error(request, "Old password is incorrect")
        elif len(p.get("new", "")) < 4:
            messages.error(request, "New password must be at least 4 characters")
        else:
            u.set_password(p["new"]); u.save(); update_session_auth_hash(request, u)
            messages.success(request, "Password changed")
            return redirect("panel-home")
    return render(request, "panel/password.html")


@panel
def attendance_page(request):
    u = request.user
    if u.role not in ("SCHOOL_ADMIN", "TEACHER"):
        return redirect("panel-home")
    cid = request.GET.get("class") or request.POST.get("class")
    day = request.GET.get("date") or request.POST.get("date") or str(date.today())
    students = []
    if cid:
        students = list(Student.objects.filter(school=u.school, classroom_id=cid).order_by("roll_no"))
        if request.method == "POST":
            for st in students:
                v = request.POST.get(f"s{st.id}")
                if v in ("P", "A", "L"):
                    Attendance.objects.update_or_create(student=st, date=day, defaults={"status": v, "marked_by": u})
            messages.success(request, "Attendance saved")
        cur = {a.student_id: a.status for a in Attendance.objects.filter(student__in=students, date=day)}
        for st in students:
            st.cur = cur.get(st.id, "P")
    return render(request, "panel/attendance.html", {
        "classes": ClassRoom.objects.filter(school=u.school), "cid": str(cid or ""), "day": day, "students": students})


@panel
def diary_add(request):
    u, p = request.user, request.POST
    if request.method == "POST" and u.role in ("TEACHER", "SCHOOL_ADMIN"):
        room = ClassRoom.objects.filter(school=u.school, pk=p.get("classroom") or 0).first()
        if room and p.get("text"):
            Diary.objects.create(school=u.school, classroom=room, teacher=u, subject=p.get("subject", ""), text=p["text"])
            messages.success(request, "Diary saved")
        else:
            messages.error(request, "Choose a class and write the diary")
    return redirect("panel-home")


# ----- Generic module manager (add / edit / delete) -----
ADM, TCH = ("SCHOOL_ADMIN",), ("SCHOOL_ADMIN", "TEACHER")
MODS = {
    "classes": dict(model=ClassRoom, title="Classes", roles=ADM, sp="school", fields=["name", "section", "class_teacher"], cols=["name", "section", "class_teacher"]),
    "students": dict(model=Student, title="Students", roles=ADM, sp="school", fields=["name", "roll_no", "classroom", "parent", "phone", "admission_date"], cols=["name", "roll_no", "classroom", "parent", "phone"]),
    "fees": dict(model=FeeRecord, title="Fees", roles=ADM, sp="student__school", fields=["student", "title", "amount", "paid_amount", "due_date", "paid_on"], cols=["student", "title", "amount", "paid_amount", "due_date"]),
    "marks": dict(model=Mark, title="Marks / Result", roles=TCH, sp="student__school", fields=["student", "exam_name", "subject", "total", "obtained"], cols=["student", "exam_name", "subject", "obtained", "total"]),
    "diary": dict(model=Diary, title="Diary", roles=TCH, sp="school", own="teacher", stamp=["teacher"], fields=["classroom", "subject", "text", "date"], cols=["date", "classroom", "subject", "text"]),
    "notices": dict(model=Notice, title="Notice Board", roles=ADM, sp="school", stamp=["posted_by"], fields=["title", "body", "date"], cols=["date", "title", "body"]),
    "timetable": dict(model=Timetable, title="Timetable (day: 1=Mon ... 7=Sun)", roles=ADM, sp="school", fields=["classroom", "day", "period", "subject", "teacher", "start_time", "end_time"], cols=["classroom", "day", "period", "subject", "teacher", "start_time", "end_time"]),
    "datesheet": dict(model=DateSheet, title="Date Sheet", roles=ADM, sp="school", fields=["classroom", "exam_name", "subject", "date", "start_time", "note"], cols=["date", "classroom", "exam_name", "subject", "start_time"]),
    "syllabus": dict(model=Syllabus, title="Syllabus", roles=TCH, sp="school", fields=["classroom", "subject", "title", "details"], cols=["classroom", "subject", "title", "details"]),
    "lessonplans": dict(model=LessonPlan, title="Lesson Plans", roles=TCH, sp="school", own="teacher", stamp=["teacher"], fields=["classroom", "subject", "topic", "plan", "date"], cols=["date", "classroom", "subject", "topic"]),
}


def _cfg(request, key):
    cfg = MODS.get(key)
    return cfg if cfg and request.user.role in cfg["roles"] else None


def _scoped(cfg, u):
    qs = cfg["model"].objects.filter(**{cfg["sp"]: u.school})
    if u.role == "TEACHER" and cfg.get("own"):
        qs = qs.filter(**{cfg["own"]: u})
    return qs


def _form(cfg, u, data=None, inst=None):
    f = forms.modelform_factory(cfg["model"], fields=cfg["fields"])(data, instance=inst)
    for name, fld in f.fields.items():
        qs = getattr(fld, "queryset", None)
        if qs is not None and hasattr(qs.model, "school"):
            qs = qs.filter(school=u.school)
            if name in ("teacher", "class_teacher"):
                qs = qs.filter(role="TEACHER")
            if name == "parent":
                qs = qs.filter(role="PARENT")
                fld.label_from_instance = lambda x: f"{x.first_name} ({x.username})" if x.first_name else x.username
            fld.queryset = qs
    return f


def _cell(o, c):
    v = getattr(o, c)
    return "" if v is None else str(v)


@panel
def mod_list(request, key):
    cfg = _cfg(request, key)
    if not cfg:
        return redirect("panel-home")
    rows = [{"pk": o.pk, "cells": [_cell(o, c) for c in cfg["cols"]]} for o in _scoped(cfg, request.user)[:500]]
    return render(request, "panel/module.html", {"key": key, "title": cfg["title"],
                  "cols": [c.replace("_", " ").title() for c in cfg["cols"]], "rows": rows})


@panel
def mod_form(request, key, pk=None):
    cfg, u = _cfg(request, key), request.user
    if not cfg:
        return redirect("panel-home")
    inst = get_object_or_404(_scoped(cfg, u), pk=pk) if pk else None
    f = _form(cfg, u, request.POST or None, inst)
    if request.method == "POST" and f.is_valid():
        o = f.save(commit=False)
        if hasattr(cfg["model"], "school"):
            o.school = u.school
        if not inst:
            for k in cfg.get("stamp", []):
                setattr(o, k, u)
        o.save()
        messages.success(request, "Saved")
        return redirect("panel-mod", key=key)
    return render(request, "panel/form.html", {"form": f, "key": key, "title": cfg["title"]})


@panel
def mod_delete(request, key, pk):
    cfg = _cfg(request, key)
    if cfg and request.method == "POST":
        get_object_or_404(_scoped(cfg, request.user), pk=pk).delete()
        messages.success(request, "Deleted")
    return redirect("panel-mod", key=key) if cfg else redirect("panel-home")


# ----- Leaves -----
def _can_review(u, lv):
    return (lv.status == "P" and lv.applicant_id != u.id and
            (u.role == "SCHOOL_ADMIN" or (u.role == "TEACHER" and lv.kind == "STUDENT")))


@panel
def leaves_page(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    qs = Leave.objects.filter(school=u.school).select_related("student", "applicant").order_by("-id")
    if u.role == "PARENT":
        qs = qs.filter(applicant=u)
    elif u.role == "TEACHER":
        qs = qs.filter(Q(kind="STUDENT") | Q(applicant=u))
    rows = list(qs[:200])
    for lv in rows:
        lv.can_review = _can_review(u, lv)
    kids = Student.objects.filter(school=u.school, parent=u) if u.role == "PARENT" else []
    return render(request, "panel/leaves.html", {"rows": rows, "kids": kids})


@panel
def leave_apply(request):
    u, p = request.user, request.POST
    if request.method == "POST" and u.role != "SUPER_ADMIN":
        try:
            if u.role == "PARENT":
                st = Student.objects.filter(school=u.school, parent=u, pk=p.get("student") or 0).first()
                if not st:
                    raise ValueError("Choose your child")
                kw = dict(kind="STUDENT", student=st)
            else:
                kw = dict(kind="STAFF")
            Leave.objects.create(school=u.school, applicant=u, from_date=p["from_date"], to_date=p["to_date"],
                                 reason=p.get("reason", ""), **kw)
            messages.success(request, "Leave request sent")
        except Exception as e:
            messages.error(request, f"Could not create leave: {e}")
    return redirect("panel-leaves")


@panel
def leave_review(request, pk):
    u = request.user
    lv = get_object_or_404(Leave, pk=pk, school=u.school) if u.school else None
    if lv and request.method == "POST" and _can_review(u, lv) and request.POST.get("status") in ("A", "R"):
        lv.status, lv.remark, lv.reviewed_by = request.POST["status"], request.POST.get("remark", ""), u
        lv.save()
        messages.success(request, "Leave updated")
    return redirect("panel-leaves")


# ----- Branding (Super admin) -----
@panel
def branding_save(request):
    if not _super_post(request):
        return redirect("panel-home")
    b, p = Branding.get(), request.POST
    if p.get("app_name", "").strip():
        b.app_name = p["app_name"].strip()[:100]
    if re.fullmatch(r"#[0-9a-fA-F]{6}", p.get("primary_color", "")):
        b.primary_color = p["primary_color"]
    f = request.FILES.get("logo")
    if p.get("remove_logo"):
        b.logo_b64 = b.logo_mime = ""
    elif f:
        if f.size > 200 * 1024 or f.content_type not in ("image/png", "image/jpeg", "image/webp"):
            messages.error(request, "Logo must be PNG/JPG and smaller than 200 KB")
        else:
            b.logo_b64, b.logo_mime = base64.b64encode(f.read()).decode(), f.content_type
    b.save()
    messages.success(request, "Branding saved")
    return redirect("panel-home")


# ----- Fees Excel -----
def _d(v):
    if hasattr(v, "date"):
        return v.date()
    return v if isinstance(v, date) else date.fromisoformat(t(v))


@panel
def import_fees(request):
    if not _admin_upload(request):
        return redirect("panel-home")
    s, ok, errs, skipped = request.user.school, 0, [], []
    only_class = t(request.POST.get("class"))
    try:
        for n, r in rows(request.FILES["file"]):
            try:
                with transaction.atomic():
                    if only_class:
                        r = {**r, "class": only_class}
                    st = find_student(s, r)
                    title = t(r.get("title"))
                    if not title:
                        raise ValueError("title is empty")
                    FeeRecord.objects.update_or_create(student=st, title=title, defaults={
                        "amount": Decimal(t(r.get("amount")) or 0), "due_date": _d(r.get("due_date")),
                        "paid_amount": Decimal(t(r.get("paid_amount")) or 0)})
                    ok += 1
            except Skip as e:
                skipped.append(f"Row {n}: {e}")
            except Exception as e:
                errs.append(f"Row {n}: {e}")
    except Exception as e:
        errs.append(f"Could not read the file (it must be .xlsx): {e}")
    report(request, ok, errs, "fee records", skipped)
    return redirect("panel-home")
