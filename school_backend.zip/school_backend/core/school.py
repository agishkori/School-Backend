"""School profile (name, colour, logo, shape, timings), picture slides, and PDF documents."""
import base64
import io
from PIL import Image, ImageOps
import re
from django.contrib import messages
from django.db.models import Q
from django.http import FileResponse, Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from .models import *
from .web import panel

IMG = ("image/png", "image/jpeg", "image/webp")


def _admin(request):
    return request.user.role == "SCHOOL_ADMIN"


@panel
def school_page(request):
    if not _admin(request):
        return redirect("panel-home")
    s = request.user.school
    return render(request, "panel/school.html", {"s": s, "slides": Slide.objects.filter(school=s)})


@panel
def school_save(request):
    if not (_admin(request) and request.method == "POST"):
        return redirect("panel-home")
    s, p = request.user.school, request.POST
    s.time_pre, s.time_school, s.time_friday = (p.get(k, "").strip()[:60] for k in ("time_pre", "time_school", "time_friday"))
    s.save()
    messages.success(request, "School timing saved")
    return redirect("panel-school")


@panel
def look_page(request, pk):
    """Super Admin only: app name, theme colour, logo and icon shape of one school."""
    if request.user.role != "SUPER_ADMIN":
        return redirect("panel-home")
    s = get_object_or_404(School, pk=pk)
    if request.method == "POST":
        p = request.POST
        s.app_name = p.get("app_name", "").strip()[:100]
        s.primary_color = p["primary_color"] if re.fullmatch(r"#[0-9a-fA-F]{6}", p.get("primary_color", "")) else ""
        s.icon_shape = p.get("icon_shape") if p.get("icon_shape") in ("round", "rounded", "square") else "rounded"
        f = request.FILES.get("logo")
        if p.get("remove_logo"):
            s.logo_b64 = s.logo_mime = ""
        elif f:
            if f.size > 300 * 1024 or f.content_type not in IMG:
                messages.error(request, "Logo must be PNG/JPG and smaller than 300 KB")
                return redirect("panel-look", pk=pk)
            s.logo_b64, s.logo_mime = base64.b64encode(f.read()).decode(), f.content_type
        s.save()
        messages.success(request, f"Look of {s.name} saved")
        return redirect("panel-look", pk=pk)
    return render(request, "panel/look.html", {"s": s, "colour": s.primary_color or "#1d4ed8"})


@panel
def slide_add(request):
    if not (_admin(request) and request.method == "POST"):
        return redirect("panel-home")
    s, f = request.user.school, request.FILES.get("image")
    if not f or f.size > 8 * 1024 * 1024:
        messages.error(request, "Choose a picture (JPG or PNG) smaller than 8 MB")
    elif Slide.objects.filter(school=s).count() >= 12:
        messages.error(request, "Maximum 12 slides. Delete an old one first.")
    else:
        try:  # any picture is cropped to the 16:9 slide shape (1200 x 675) and compressed
            img = ImageOps.exif_transpose(Image.open(f)).convert("RGB")
            img = ImageOps.fit(img, (1200, 675), Image.LANCZOS)
            buf = io.BytesIO(); img.save(buf, "JPEG", quality=85, optimize=True)
        except Exception:
            messages.error(request, "This file is not a valid picture. Use JPG or PNG.")
            return redirect("panel-school")
        Slide.objects.create(school=s, title=request.POST.get("title", "")[:120], image_b64=base64.b64encode(buf.getvalue()).decode(), mime="image/jpeg")
        messages.success(request, "Slide added")
    return redirect("panel-school")


@panel
def slide_delete(request, pk):
    if _admin(request) and request.method == "POST":
        get_object_or_404(Slide, pk=pk, school=request.user.school).delete()
        messages.success(request, "Slide deleted")
    return redirect("panel-school")


@panel
def slide_img(request, pk):
    sl = get_object_or_404(Slide, pk=pk, school=request.user.school)
    r = HttpResponse(base64.b64decode(sl.image_b64), content_type=sl.mime)
    r["Cache-Control"] = "private, max-age=3600"
    return r


def _docs_for(u):
    qs = Document.objects.filter(school=u.school).select_related("classroom")
    if u.role == "PARENT":
        rooms = Student.objects.filter(parent=u).exclude(classroom=None).values("classroom")
        qs = qs.filter(Q(classroom=None) | Q(classroom__in=rooms))
    return qs


@panel
def docs_page(request):
    u = request.user
    if u.role == "SUPER_ADMIN":
        return redirect("panel-home")
    return render(request, "panel/docs.html", {"docs": _docs_for(u)[:200], "classes": ClassRoom.objects.filter(school=u.school),
                                               "can_upload": u.role in ("SCHOOL_ADMIN", "TEACHER")})


@panel
def doc_add(request):
    u = request.user
    f = request.FILES.get("file")
    if request.method == "POST" and u.role in ("SCHOOL_ADMIN", "TEACHER"):
        if not f or not f.name.lower().endswith(".pdf") or f.size > 8 * 1024 * 1024 or f.read(5) != b"%PDF-":
            messages.error(request, "Choose a PDF file smaller than 8 MB")
        else:
            f.seek(0)
            room = ClassRoom.objects.filter(school=u.school, pk=request.POST.get("classroom") or 0).first()
            title = request.POST.get("title", "").strip()[:150] or f.name[:-4]
            Document.objects.create(school=u.school, classroom=room, title=title, file=f, uploaded_by=u)
            messages.success(request, "PDF uploaded")
    return redirect("panel-docs")


@panel
def doc_delete(request, pk):
    u = request.user
    d = get_object_or_404(Document, pk=pk, school=u.school)
    if request.method == "POST" and (u.role == "SCHOOL_ADMIN" or d.uploaded_by_id == u.id):
        d.file.delete(save=False); d.delete()
        messages.success(request, "PDF deleted")
    return redirect("panel-docs")


@panel
def doc_file(request, pk):
    d = get_object_or_404(_docs_for(request.user), pk=pk)
    try:
        return FileResponse(d.file.open("rb"), as_attachment=request.GET.get("dl") == "1",
                            filename=re.sub(r"[^\w .-]", "_", d.title) + ".pdf", content_type="application/pdf")
    except FileNotFoundError:
        raise Http404
