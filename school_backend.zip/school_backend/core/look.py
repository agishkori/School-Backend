"""Per-school look: name, colour, logo, icon shape. Falls back to the Super Admin defaults."""
from types import SimpleNamespace
from .models import Branding, School


def look_for(school):
    b = Branding.get()
    s = school
    return SimpleNamespace(
        app_name=(s.app_name if s and s.app_name else b.app_name),
        primary_color=(s.primary_color if s and s.primary_color else b.primary_color),
        logo_b64=(s.logo_b64 if s and s.logo_b64 else b.logo_b64),
        logo_mime=(s.logo_mime if s and s.logo_mime else b.logo_mime),
        icon_shape=(s.icon_shape if s else "rounded"), school_id=(s.pk if s else None))


def radius(shape, pct=True):
    return {"round": "50%", "square": "6px"}.get(shape, "22%")
