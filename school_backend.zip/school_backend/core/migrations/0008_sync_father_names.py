from django.db import migrations


def sync(apps, schema_editor):
    User, Student = apps.get_model("core", "User"), apps.get_model("core", "Student")
    for u in User.objects.filter(role="PARENT"):
        kids = list(Student.objects.filter(parent=u).order_by("-id"))
        name = next((k.father_name for k in kids if k.father_name), "") if kids else ""
        if u.first_name != name:
            u.first_name = name
            u.save(update_fields=["first_name"])


class Migration(migrations.Migration):
    dependencies = [("core", "0007_document_kind")]
    operations = [migrations.RunPython(sync, migrations.RunPython.noop)]
