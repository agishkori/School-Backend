from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [("core", "0003_chatmessage_notification")]
    operations = [
        migrations.AddField(model_name="student", name="father_cnic",
                            field=models.CharField(max_length=15, blank=True, db_index=True)),
        migrations.AddField(model_name="feerecord", name="updated_on",
                            field=models.DateField(auto_now=True, null=True, blank=True)),
    ]
