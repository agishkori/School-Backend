from rest_framework import serializers
from .models import *


class Base(serializers.ModelSerializer):
    def validate(self, attrs):
        u = self.context["request"].user
        if u.role != "SUPER_ADMIN":  # cannot link data from another school
            for val in attrs.values():
                if hasattr(val, "school_id") and val.school_id != u.school_id:
                    raise serializers.ValidationError("Invalid reference")
        return attrs


def ser(model, ro=(), **extra):
    meta = type("Meta", (), {"model": model, "fields": "__all__", "read_only_fields": list(ro)})
    return type(model.__name__ + "S", (Base,), {"Meta": meta, **extra})


def _cn(self, o):
    c = getattr(o, "classroom", None)
    return c.name if c else ""


cn = dict(cname=serializers.SerializerMethodField(), get_cname=_cn)
sn = dict(sname=serializers.SerializerMethodField(), get_sname=lambda self, o: o.student.name)
SchoolS = ser(School)
ClassRoomS = ser(ClassRoom, ["school"])
from .people import norm_cnic


def _val_cnic(self, v):
    if v and not norm_cnic(v):
        raise serializers.ValidationError("Father CNIC must be 13 digits")
    return norm_cnic(v)


StudentS = ser(Student, ["school", "student_id", "parent"], validate_father_cnic=_val_cnic, **cn)
TeacherS = ser(TeacherProfile)
AttendanceS = ser(Attendance, ["marked_by"], **sn)
FeeS = ser(FeeRecord, balance=serializers.ReadOnlyField(), **sn)
MarkS = ser(Mark, percentage=serializers.ReadOnlyField(), **sn)
NoticeS = ser(Notice, ["school", "posted_by"])
TimetableS = ser(Timetable, ["school"], **cn)
DateSheetS = ser(DateSheet, ["school"], **cn)
LessonPlanS = ser(LessonPlan, ["school", "teacher"], **cn)


class LeaveS(Base):
    student_name = serializers.SerializerMethodField()
    applicant_name = serializers.SerializerMethodField()

    class Meta:
        model = Leave
        fields = "__all__"
        read_only_fields = ["school", "kind", "applicant", "status", "remark", "reviewed_by"]

    def get_student_name(self, o):
        return o.student.name if o.student else ""

    def get_applicant_name(self, o):
        return o.applicant.first_name or o.applicant.username
DiaryS = ser(Diary, ["school", "teacher"])


class UserS(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ["id", "username", "password", "first_name", "role", "phone", "is_active"]
        read_only_fields = ["is_active"]

    def validate_role(self, v):
        if v not in ("TEACHER", "PARENT"):
            raise serializers.ValidationError("Only TEACHER or PARENT")
        return v

    def create(self, data):
        pw = data.pop("password")
        return User.objects.create_user(password=pw, **data)

    def update(self, inst, data):
        pw = data.pop("password", None)
        for k, v in data.items():
            setattr(inst, k, v)
        if pw:
            inst.set_password(pw)
        inst.save()
        return inst


class AdminUserS(UserS):
    class Meta(UserS.Meta):
        fields = ["id", "username", "password", "first_name", "phone", "school", "is_active"]
        read_only_fields = ["is_active"]

    def create(self, data):
        if not data.get("school"):
            raise serializers.ValidationError({"school": "Choose a school"})
        pw, sc = data.pop("password"), data["school"]
        sc.is_active = True; sc.save()
        return User.objects.create_user(password=pw, role="SCHOOL_ADMIN", **data)
