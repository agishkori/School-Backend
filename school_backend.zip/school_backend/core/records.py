"""Students / Fees / Results: choose the class first, then add by hand or by Excel. Single and whole delete."""
import io
import re
from decimal import Decimal, InvalidOperation
from django.contrib import messages
from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from openpyxl import Workbook, load_workbook
from .models import *
from .people import fmt_cnic, link_parent, norm_cnic
from .web import panel

KINDS = {
    "students": dict(title="Students", roles=("SCHOOL_ADMIN",)),
    "fees": dict(title="Fees (balance)", roles=("SCHOOL_ADMIN",)),
    "results": dict(title="Results", roles=("SCHOOL_ADMIN", "TEACHER")),
}
HEAD = {
    "students": ["roll_no", "name", "father_name", "mobile", "father_cnic"],
    "fees": ["father_cnic", "roll_no", "balance"],
    "results": ["father_cnic", "roll_no", "Name", "Father's Name", "<one column per subject>"],
}
SAMPLE = {
    "students": [["1", "Ali Khan", "Khan Sahib", "03001234567", "3520212345671"]],
    "fees": [["3520212345671", "1", 2500]],
    "results": [["3520212345671", "1", "Mid Term", 100, 78, 85, 90]],
}


class Skip(Exception):
    """Row skipped on purpose: the student is not in this class, nothing is saved."""


def t(v):
    s = "" if v is None else str(v).strip()
    return s[:-2] if s.endswith(".0") else s


def dec(v):
    try:
        return Decimal(t(v).replace(",", "") or 0)
    except InvalidOperation:
        raise ValueError(f"'{v}' is not a number")


def _ctx(request, kind):
    cfg = KINDS.get(kind)
    if not cfg or request.user.role not in cfg["roles"]:
        return None, None, None
    u = request.user
    room = ClassRoom.objects.filter(school=u.school, pk=request.GET.get("class") or request.POST.get("class") or 0).first()
    return cfg, u, room


def find_in_class(room, r):
    """Match a sheet row to a student of THIS class: student_id, then father CNIC (+ roll no / name)."""
    qs = Student.objects.filter(school=room.school, classroom=room)
    sid = t(r.get("student_id") or r.get("id")).upper()
    if sid:
        st = qs.filter(student_id=sid).first()
        if st:
            return st
    cnic = norm_cnic(r.get("father_cnic") or r.get("cnic") or r.get("id_card"))
    if not cnic:
        raise ValueError("father_cnic (13 digits) is empty or wrong")
    found = list(qs.filter(father_cnic=cnic))
    if len(found) > 1:
        roll, name = t(r.get("roll_no")), t(r.get("name") or r.get("student_name")).lower()
        found = [x for x in found if (roll and x.roll_no == roll) or (name and x.name.lower() == name)] or found
        if len(found) > 1:
            raise Skip(f"father CNIC {fmt_cnic(cnic)} has {len(found)} students in this class: add roll_no")
    if not found:
        raise Skip(f"no student with CNIC {fmt_cnic(cnic)} in this class")
    return found[0]


def read_rows(f):
    it = load_workbook(f, data_only=True).active.iter_rows(values_only=True)
    head = [t(h).lower() for h in next(it)]
    for n, r in enumerate(it, start=2):
        if any(c not in (None, "") for c in r):
            yield n, dict(zip(head, r))


def save_student(school, room, d, st=None):
    name, cnic = t(d.get("name")), norm_cnic(d.get("father_cnic"))
    if not name:
        raise ValueError("student name is required")
    if not cnic:
        raise ValueError("father CNIC must be 13 digits")
    if st is None:
        if Student.objects.filter(school=school).count() >= school.max_students:
            raise ValueError("Maximum student limit reached")
        st = Student(school=school, classroom=room)
    st.name, st.father_cnic = name, cnic
    st.father_name, st.roll_no, st.phone = t(d.get("father_name")), t(d.get("roll_no")), t(d.get("mobile") or d.get("phone"))
    st.save()
    user, pw = link_parent(st)
    return st, pw


def row_student(school, room, r):
    cnic, name, roll = norm_cnic(r.get("father_cnic")), t(r.get("name")).lower(), t(r.get("roll_no"))
    same = Student.objects.filter(school=school, classroom=room, father_cnic=cnic) if cnic else Student.objects.none()
    st = next((x for x in same if (roll and x.roll_no == roll) or x.name.lower() == name), None)
    save_student(school, room, r, st)


def row_fee(school, room, r):
    st = find_in_class(room, r)
    FeeBalance.objects.update_or_create(student=st, defaults={"balance": dec(r.get("balance")), "updated_at": timezone.now()})


def row_result(school, room, r):
    st = find_in_class(room, r)
    exam = t(r.get("exam_name"))
    if not exam:
        raise ValueError("exam_name is empty")
    total = int(float(t(r.get("total_marks")) or 100))
    fixed = {"father_cnic", "cnic", "id_card", "roll_no", "student_id", "id", "exam_name", "total_marks", "name", "student_name", "class", "section"}
    n = 0
    for subj, val in r.items():
        if not subj or subj in fixed or val in (None, ""):
            continue
        Mark.objects.update_or_create(student=st, exam_name=exam, subject=subj.title(),
                                      defaults={"total": total, "obtained": dec(val)})
        n += 1
    if not n:
        raise ValueError("no subject marks in this row")


ROW = {"students": row_student, "fees": row_fee, "results": row_result}


@panel
def rec_list(request, kind):
    cfg, u, room = _ctx(request, kind)
    if not cfg:
        return redirect("panel-home")
    ctx = {"kind": kind, "title": cfg["title"], "room": room, "classes": ClassRoom.objects.filter(school=u.school).order_by("name", "section"),
           "head": HEAD[kind], "can_delete": u.role == "SCHOOL_ADMIN" or kind == "results"}
    if room:
        studs = Student.objects.filter(school=u.school, classroom=room).order_by("roll_no", "name")
        ctx["students"] = studs
        if kind == "students":
            ctx["rows"] = studs
        elif kind == "fees":
            ctx["rows"] = FeeBalance.objects.filter(student__in=studs).select_related("student").order_by("student__roll_no")
        else:
            ctx["subjects"] = list(ClassSubject.objects.filter(classroom=room))
            exams = list(Mark.objects.filter(student__in=studs).values_list("exam_name", flat=True).distinct())
            exam = request.GET.get("exam", "")
            qs = Mark.objects.filter(student__in=studs).select_related("student").order_by("student__roll_no", "exam_name", "subject")
            ctx.update(exams=exams, exam=exam, rows=qs.filter(exam_name=exam) if exam else qs)
    return render(request, "panel/records.html", ctx)


def _back(kind, room, exam=""):
    return redirect(f"/panel/rec/{kind}/?class={room.pk if room else ''}" + (f"&exam={exam}" if exam else ""))


@panel
def rec_add(request, kind):
    cfg, u, room = _ctx(request, kind)
    if not cfg or not room or request.method != "POST":
        return redirect("panel-home")
    p = request.POST
    try:
        with transaction.atomic():
            if kind == "students":
                st, pw = save_student(u.school, room, p)
                msg = f"Saved: {st.name} ({st.student_id})."
                if pw:
                    msg += f" New parent login: CNIC {fmt_cnic(st.father_cnic)}, password {pw}"
                messages.success(request, msg)
            else:
                st = get_object_or_404(Student, pk=p.get("student") or 0, school=u.school, classroom=room)
                if kind == "fees":
                    FeeBalance.objects.update_or_create(student=st, defaults={"balance": dec(p.get("balance")), "updated_at": timezone.now()})
                else:
                    if not t(p.get("exam_name")) or not t(p.get("subject")):
                        raise ValueError("Enter exam name and subject")
                    Mark.objects.update_or_create(student=st, exam_name=t(p["exam_name"]), subject=t(p["subject"]).title(),
                                                  defaults={"total": int(p.get("total") or 100), "obtained": dec(p.get("obtained"))})
                messages.success(request, "Saved")
    except Exception as e:
        messages.error(request, str(e))
    return _back(kind, room, p.get("exam_name", "") if kind == "results" else "")


def _obj(kind, u, pk):
    if kind == "students":
        return get_object_or_404(Student, pk=pk, school=u.school)
    if kind == "fees":
        return get_object_or_404(FeeBalance, pk=pk, student__school=u.school)
    return get_object_or_404(Mark, pk=pk, student__school=u.school)


@panel
def rec_edit(request, kind, pk):
    cfg, u, _ = _ctx(request, kind)
    if not cfg:
        return redirect("panel-home")
    o = _obj(kind, u, pk)
    st = o if kind == "students" else o.student
    if request.method == "POST":
        p = request.POST
        try:
            with transaction.atomic():
                if kind == "students":
                    save_student(u.school, st.classroom, p, o)
                elif kind == "fees":
                    o.balance, o.updated_at = dec(p.get("balance")), timezone.now(); o.save()
                else:
                    o.exam_name, o.subject = t(p.get("exam_name")), t(p.get("subject")).title()
                    o.total, o.obtained = int(p.get("total") or 100), dec(p.get("obtained")); o.save()
            messages.success(request, "Saved")
            return _back(kind, st.classroom)
        except Exception as e:
            messages.error(request, str(e))
    return render(request, "panel/record_edit.html", {"kind": kind, "title": cfg["title"], "o": o, "st": st, "cnic": fmt_cnic(st.father_cnic)})


@panel
def rec_delete(request, kind, pk):
    cfg, u, _ = _ctx(request, kind)
    if not cfg or request.method != "POST":
        return redirect("panel-home")
    o = _obj(kind, u, pk)
    room = o.classroom if kind == "students" else o.student.classroom
    o.delete()
    _orphans(u.school)
    messages.success(request, "Deleted")
    return _back(kind, room)


def _orphans(school):
    User.objects.filter(school=school, role="PARENT", children__isnull=True, last_login__isnull=True).delete()


@panel
def rec_delete_all(request, kind):
    cfg, u, room = _ctx(request, kind)
    if not cfg or not room or request.method != "POST":
        return redirect("panel-home")
    if request.POST.get("confirm", "").strip().upper() != "DELETE":
        messages.error(request, "Nothing deleted. Type DELETE to confirm.")
        return _back(kind, room)
    studs = Student.objects.filter(school=u.school, classroom=room)
    if kind == "students":
        n = studs.count(); studs.delete(); _orphans(u.school)
    elif kind == "fees":
        n = FeeBalance.objects.filter(student__in=studs).delete()[0]
    else:
        qs = Mark.objects.filter(student__in=studs)
        if request.POST.get("exam"):
            qs = qs.filter(exam_name=request.POST["exam"])
        n = qs.delete()[0]
    messages.success(request, f"Deleted {n} record(s) of {room}")
    return _back(kind, room)


def _key(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


@panel
def rec_subject_add(request):
    cfg, u, room = _ctx(request, "results")
    if cfg and room and request.method == "POST":
        for nm in re.split(r"[,\n]", request.POST.get("names", "")):
            nm = nm.strip()[:60]
            if nm and not any(_key(x.name) == _key(nm) for x in ClassSubject.objects.filter(classroom=room)):
                ClassSubject.objects.create(classroom=room, name=nm)
    return _back("results", room)


@panel
def rec_subject_delete(request, pk):
    cfg, u, _ = _ctx(request, "results")
    sub = get_object_or_404(ClassSubject, pk=pk, classroom__school=u.school)
    room = sub.classroom
    if cfg and request.method == "POST":
        sub.delete()
    return _back("results", room)


def import_results(request, u, room, f):
    """Class + exam name + total marks per subject are chosen on the page; the sheet only holds marks."""
    exam = t(request.POST.get("exam_name"))
    subs = list(ClassSubject.objects.filter(classroom=room))
    if not exam:
        raise ValueError("Write the result / exam name first")
    if not subs:
        raise ValueError("Add the subjects of this class first")
    totals = {}
    for s in subs:
        try:
            totals[s.pk] = int(float(t(request.POST.get(f"total_{s.pk}")) or 100))
        except ValueError:
            raise ValueError(f"Total marks of {s.name} must be a number")
    by_key = {_key(s.name): s for s in subs}
    ok, skipped, errs, seen = 0, [], [], set()
    for n, r in read_rows(f):
        if n == 2:
            ignored = [h for h in r if h and _key(h) not in by_key and _key(h) not in IDCOLS]
            seen = {_key(h) for h in r if _key(h) in by_key}
            if ignored:
                errs.append("Columns ignored (not a subject of this class): " + ", ".join(ignored))
            missing = [s.name for s in subs if _key(s.name) not in seen]
            if missing:
                errs.append("Subjects not in the sheet: " + ", ".join(missing))
        try:
            st = find_in_class(room, r)
            with transaction.atomic():
                got = 0
                for h, val in r.items():
                    s = by_key.get(_key(h))
                    if s and val not in (None, ""):
                        Mark.objects.update_or_create(student=st, exam_name=exam, subject=s.name,
                                                      defaults={"total": totals[s.pk], "obtained": dec(val)})
                        got += 1
                if not got:
                    raise ValueError("no marks in this row")
            ok += 1
        except Skip as e:
            skipped.append(f"Row {n}: {e}")
        except Exception as e:
            errs.append(f"Row {n}: {e}")
    return ok, skipped, errs


IDCOLS = {"fathercnic", "cnic", "idcard", "rollno", "studentid", "id", "name", "studentname", "fathersname", "fathername", "class", "section"}


@panel
def rec_import(request, kind):
    cfg, u, room = _ctx(request, kind)
    f = request.FILES.get("file")
    if not cfg or not room or request.method != "POST" or not f:
        messages.error(request, "Choose a class and an Excel file first")
        return _back(kind, room)
    ok, errs, skipped = 0, [], []
    try:
        if kind == "results":
            ok, skipped, errs = import_results(request, u, room, f)
        else:
            for n, r in read_rows(f):
                try:
                    with transaction.atomic():
                        ROW[kind](u.school, room, r)
                    ok += 1
                except Skip as e:
                    skipped.append(f"Row {n}: {e}")
                except Exception as e:
                    errs.append(f"Row {n}: {e}")
    except Exception as e:
        errs.append(f"Could not read the file (it must be .xlsx): {e}")
    messages.success(request, f"{ok} row(s) saved/updated in {room}")
    if skipped:
        messages.warning(request, f"{len(skipped)} row(s) skipped (not in this class, nothing saved): " + "; ".join(skipped[:8]) + (" ..." if len(skipped) > 8 else ""))
    for e in errs[:10]:
        messages.warning(request, e)
    return _back(kind, room, t(request.POST.get("exam_name")) if kind == "results" else "")


def _xlsx(name, head, data):
    wb = Workbook(); ws = wb.active; ws.append(head)
    for r in data:
        ws.append(r)
    resp = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = f'attachment; filename="{name}"'
    wb.save(resp)
    return resp


@panel
def rec_template(request, kind):
    cfg, u, _ = _ctx(request, kind)
    if not cfg:
        return redirect("panel-home")
    if kind == "results":
        room = ClassRoom.objects.filter(school=u.school, pk=request.GET.get("class") or 0).first()
        subs = [s.name for s in ClassSubject.objects.filter(classroom=room)] if room else []
        subs = subs or ["Math", "English", "Urdu"]
        return _xlsx("results_template.xlsx", ["father_cnic", "roll_no", "Name", "Father's Name"] + subs,
                     [["3520212345671", "1", "Student name", "Father name"] + [80] * len(subs)])
    return _xlsx(f"{kind}_template.xlsx", HEAD[kind], SAMPLE[kind])


@panel
def rec_export(request, kind):
    cfg, u, room = _ctx(request, kind)
    if not cfg or not room:
        return redirect("panel-home")
    studs = Student.objects.filter(school=u.school, classroom=room).order_by("roll_no")
    if kind == "students":
        data = [[s.roll_no, s.name, s.father_name, s.phone, s.father_cnic] for s in studs]
    elif kind == "fees":
        data = [[s.student.father_cnic, s.student.roll_no, float(s.balance)] for s in FeeBalance.objects.filter(student__in=studs).select_related("student")]
    else:
        return _xlsx("results.xlsx", ["father_cnic", "roll_no", "name", "exam_name", "subject", "total", "obtained"],
                     [[m.student.father_cnic, m.student.roll_no, m.student.name, m.exam_name, m.subject, m.total, float(m.obtained)]
                      for m in Mark.objects.filter(student__in=studs).select_related("student")])
    return _xlsx(f"{kind}.xlsx", HEAD[kind], data)
