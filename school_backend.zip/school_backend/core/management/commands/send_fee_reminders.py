"""Remind parents about unpaid fees that are due within 3 days or already overdue.
Run once a day (PythonAnywhere: Tasks tab):  python manage.py send_fee_reminders"""
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from core.models import FeeRecord, Notification
from core.signals import _d, _money


class Command(BaseCommand):
    help = "Send fee due / overdue alerts to parents (each alert is sent once; overdue repeats weekly)"

    def handle(self, *args, **kwargs):
        today, sent = timezone.localdate(), 0
        wk = "%d-%02d" % today.isocalendar()[:2]
        qs = FeeRecord.objects.filter(due_date__lte=today + timedelta(days=3)).select_related("student__parent")
        for f in qs:
            parent, bal = f.student.parent, f.amount - f.paid_amount
            if bal <= 0 or not parent or not parent.is_active:
                continue
            late = f.due_date < today
            _, made = Notification.objects.get_or_create(
                user=parent, key=f"due:{f.id}:{wk if late else 'soon'}",
                defaults=dict(title="Fee overdue" if late else "Fee due soon", kind="fee", url="/panel/my/fees/",
                              body=f"{f.title} for {f.student.name}: Rs {_money(bal)} {'was due on' if late else 'is due on'} {_d(f.due_date):%d %b %Y}."))
            sent += made
        self.stdout.write(f"{sent} reminder(s) sent")
