"""Weekly reminder to parents whose child still has a fee balance.
Run once a day (PythonAnywhere: Tasks tab):  python manage.py send_fee_reminders  (it sends at most once per week)"""
from django.core.management.base import BaseCommand
from django.utils import timezone
from core.models import FeeBalance, Notification
from core.signals import _money


class Command(BaseCommand):
    help = "Send a weekly fee balance alert to parents"

    def handle(self, *args, **kwargs):
        wk = "%d-%02d" % timezone.localdate().isocalendar()[:2]
        sent = 0
        for fb in FeeBalance.objects.filter(balance__gt=0).select_related("student__parent"):
            p = fb.student.parent
            if not p or not p.is_active:
                continue
            _, made = Notification.objects.get_or_create(
                user=p, key=f"feeweek:{fb.student_id}:{wk}",
                defaults=dict(title="Fee balance", kind="fee", url="/panel/my/fees/",
                              body=f"{fb.student.name}: remaining balance Rs {_money(fb.balance)}. For any information visit Office."))
            sent += made
        self.stdout.write(f"{sent} reminder(s) sent")
