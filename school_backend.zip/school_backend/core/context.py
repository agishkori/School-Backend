from .models import Branding

NAV = {
    "SCHOOL_ADMIN": [("/panel/m/classes/", "Classes"), ("/panel/m/students/", "Students"), ("/panel/attendance/", "Attendance"),
                     ("/panel/m/fees/", "Fees"), ("/panel/m/marks/", "Marks"), ("/panel/m/diary/", "Diary"),
                     ("/panel/m/notices/", "Notices"), ("/panel/m/timetable/", "Timetable"), ("/panel/m/datesheet/", "Date Sheet"),
                     ("/panel/m/syllabus/", "Syllabus"), ("/panel/m/lessonplans/", "Lesson Plans"), ("/panel/leaves/", "Leaves")],
    "TEACHER": [("/panel/attendance/", "Attendance"), ("/panel/m/marks/", "Marks"), ("/panel/m/diary/", "Diary"),
                ("/panel/m/syllabus/", "Syllabus"), ("/panel/m/lessonplans/", "Lesson Plans"), ("/panel/leaves/", "Leaves")],
    "PARENT": [("/panel/leaves/", "Leaves")],
}


def brand(request):
    ctx = {"brand": Branding.get()}
    u = getattr(request, "user", None)
    if u is not None and u.is_authenticated:
        ctx["nav"] = [{"url": "/panel/", "title": "Home"}] + [{"url": a, "title": b} for a, b in NAV.get(u.role, [])]
    return ctx
