from django.conf import settings
from .models import Branding, ChatMessage, Notification
from .look import look_for, radius
from .ui import TILES


def brand(request):
    u = getattr(request, "user", None)
    sch = u.school if u is not None and u.is_authenticated else None
    b = look_for(sch)
    ctx = {"brand": b, "app_version": settings.APP_VERSION, "shape_r": radius(b.icon_shape), "sq": f"?s={sch.pk}" if sch else ""}
    if u is not None and u.is_authenticated:
        ctx["nav"] = [{"url": "/panel/", "title": "Home"}] + [{"url": t["url"], "title": t["title"]} for t in TILES.get(u.role, [])]
        if u.role != "SUPER_ADMIN":  # bottom bar: Home / Alerts / Chats
            p = request.path
            ctx.update(bottom=True, tab="alerts" if p.startswith("/panel/alerts") else "chats" if p.startswith("/panel/chats") else "home",
                       unread_alerts=Notification.objects.filter(user=u, is_read=False).count(),
                       unread_chats=ChatMessage.objects.filter(recipient=u, is_read=False, **({"sender__role": "TEACHER"} if u.role in ("PARENT", "SCHOOL_ADMIN") else {})).count())
    return ctx
