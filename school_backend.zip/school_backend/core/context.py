from .models import Branding, ChatMessage, Notification
from .ui import TILES


def brand(request):
    ctx = {"brand": Branding.get()}
    u = getattr(request, "user", None)
    if u is not None and u.is_authenticated:
        ctx["nav"] = [{"url": "/panel/", "title": "Home"}] + [{"url": t["url"], "title": t["title"]} for t in TILES.get(u.role, [])]
        if u.role != "SUPER_ADMIN":  # bottom bar: Home / Alerts / Chats
            p = request.path
            ctx.update(bottom=True, tab="alerts" if p.startswith("/panel/alerts") else "chats" if p.startswith("/panel/chats") else "home",
                       unread_alerts=Notification.objects.filter(user=u, is_read=False).count(),
                       unread_chats=ChatMessage.objects.filter(recipient=u, is_read=False, **({"sender__role": "TEACHER"} if u.role in ("PARENT", "SCHOOL_ADMIN") else {})).count())
    return ctx
