import re
import secrets
from decimal import Decimal
from datetime import date
from django.contrib.auth import authenticate
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from rest_framework import viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import action, api_view, authentication_classes, permission_classes
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .models import *
from .people import link_parent, login_name
from .permissions import IsSuperAdmin, RolePermission
from .serializers import *

ADMIN, TEACHER, PARENT = "SCHOOL_ADMIN", "TEACHER", "PARENT"


class UserActions:  # password badalna + active/inactive
    @action(detail=True, methods=["post"])
    def set_password(self, request, pk=None):
        u, pw = self.get_object(), request.data.get("password", "")
        if len(pw) < 4:
            return Response({"error": "Password must be at least 4 characters"}, status=400)
        u.set_password(pw); u.save()
        Token.objects.filter(user=u).delete()
        return Response({"ok": True})

    @action(detail=True, methods=["post"])
    def set_active(self, request, pk=None):
        u = self.get_object()
        u.is_active = bool(request.data.get("active"))
        u.save()
        if not u.is_active:
            Token.objects.filter(user=u).delete()
        return Response({"ok": True, "is_active": u.is_active})


def _auth_payload(u):
    t, _ = Token.objects.get_or_create(user=u)
    return {"token": t.key, "role": u.role, "name": u.first_name,
            "school": u.school.name if u.school else None}


LABEL = {"SUPER_ADMIN": "Super Admin", "SCHOOL_ADMIN": "Admin", "TEACHER": "Teacher", "PARENT": "Student/Parent"}
ROLE_MAP = {"ADMIN": "SCHOOL_ADMIN", "TEACHER": "TEACHER", "PARENT": "PARENT", "SUPER_ADMIN": "SUPER_ADMIN"}


@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def login(request):
    d = request.data
    name = login_name(d.get("username"))
    u = authenticate(username=name, password=d.get("password"))
    if not u:
        x = User.objects.filter(username=name).first()
        if x and not x.is_active and x.check_password(d.get("password") or ""):
            return Response({"error": "Your account is inactive. Please contact your admin"}, status=403)
        return Response({"error": "Incorrect username or password"}, status=401)
    want = ROLE_MAP.get(d.get("role"))
    if want and u.role != want:
        return Response({"error": f"This account is {LABEL[u.role]}, but {LABEL[want]} was selected"}, status=403)
    if u.role != "SUPER_ADMIN" and not (u.school and u.school.is_valid()):
        return Response({"error": "Your school is inactive or its subscription has expired"}, status=403)
    return Response(_auth_payload(u))


@api_view(["POST"])
def change_password(request):
    u, new = request.user, request.data.get("new", "")
    if not u.check_password(request.data.get("old", "")):
        return Response({"error": "Old password is incorrect"}, status=400)
    if len(new) < 4:
        return Response({"error": "New password must be at least 4 characters"}, status=400)
    u.set_password(new); u.save()
    return Response({"ok": True})


@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def activate(request):
    d = request.data
    with transaction.atomic():
        code = ActivationCode.objects.select_related("school").filter(
            code=str(d.get("code", "")).strip().upper(), used_at__isnull=True).first()
        if not code:
            return Response({"error": "Invalid code, or it has already been used"}, status=400)
        if code.school.expires_on < date.today():
            return Response({"error": "This code has expired"}, status=400)
        if not d.get("username") or not d.get("password"):
            return Response({"error": "Enter a username and password"}, status=400)
        if User.objects.filter(username=d["username"]).exists():
            return Response({"error": "This username already exists"}, status=400)
        u = User.objects.create_user(username=d["username"], password=d["password"],
                                     first_name=d.get("full_name", ""), role=ADMIN, school=code.school)
        code.used_at = timezone.now(); code.save()
        code.school.is_active = True; code.school.save()
    return Response(_auth_payload(u), status=201)


@api_view(["GET"])
def me(request):
    u = request.user
    return Response({"id": u.id, "name": u.first_name, "role": u.role,
                     "school": u.school.name if u.school else None,
                     "school_expires": u.school.expires_on if u.school else None})


class SchoolAdminVS(viewsets.ModelViewSet):  # Super admin: schools + codes
    queryset = School.objects.all()
    serializer_class = SchoolS
    permission_classes = [IsSuperAdmin]

    @action(detail=True, methods=["post"])
    def generate_code(self, request, pk=None):
        school = self.get_object()
        code = "SCH-%s-%s" % (secrets.token_hex(2).upper(), secrets.token_hex(2).upper())
        ActivationCode.objects.create(code=code, school=school)
        return Response({"code": code, "school": school.name})

    @action(detail=True, methods=["post"])
    def set_active(self, request, pk=None):
        sc = self.get_object()
        sc.is_active = bool(request.data.get("active"))
        sc.save()
        return Response({"ok": True, "is_active": sc.is_active})


class AdminUserVS(UserActions, viewsets.ModelViewSet):  # Super admin: School Admins
    queryset = User.objects.filter(role=ADMIN)
    serializer_class = AdminUserS
    permission_classes = [IsSuperAdmin]


class ScopedVS(viewsets.ModelViewSet):
    permission_classes = [RolePermission]
    read_roles = (ADMIN, TEACHER, PARENT)
    write_roles = (ADMIN,)
    school_path = "school"
    parent_path = None      # parent sees only their own children's data
    teacher_path = None     # teacher sees only their own data
    parent_all = False      # parent sees school-wide data (notices)
    filters = {}            # ?param= -> queryset lookup

    def get_queryset(self):
        u, qs = self.request.user, self.queryset.all()
        if u.role != "SUPER_ADMIN":
            qs = qs.filter(**{self.school_path: u.school})
            if u.role == PARENT and not self.parent_all:
                qs = qs.filter(**{self.parent_path: u}).distinct() if self.parent_path else qs.none()
            if u.role == TEACHER and self.teacher_path:
                qs = qs.filter(**{self.teacher_path: u})
        for p, lookup in self.filters.items():
            if self.request.query_params.get(p):
                qs = qs.filter(**{lookup: self.request.query_params[p]})
        return qs

    def extra_save(self):
        return {}

    def perform_create(self, s):
        u = self.request.user
        kw = {"school": u.school} if ("school" in [f.name for f in self.queryset.model._meta.fields]
                                     and u.role != "SUPER_ADMIN") else {}
        s.save(**kw, **self.extra_save())


class ClassRoomVS(ScopedVS):
    queryset = ClassRoom.objects.all(); serializer_class = ClassRoomS
    read_roles = (ADMIN, TEACHER)


class StudentVS(ScopedVS):
    queryset = Student.objects.all(); serializer_class = StudentS
    parent_path = "parent"
    filters = {"classroom": "classroom_id"}

    def perform_update(self, serializer):
        super().perform_update(serializer)
        link_parent(serializer.instance)

    def perform_create(self, serializer):
        super().perform_create(serializer)
        link_parent(serializer.instance)


class TeacherVS(ScopedVS):
    queryset = TeacherProfile.objects.all(); serializer_class = TeacherS
    read_roles = (ADMIN, TEACHER)
    school_path = "user__school"; teacher_path = "user"


class UserVS(UserActions, ScopedVS):  # School admin creates teacher/parent accounts
    queryset = User.objects.filter(role__in=[TEACHER, PARENT]); serializer_class = UserS
    read_roles = (ADMIN,)
    filters = {"role": "role"}


class AttendanceVS(ScopedVS):
    queryset = Attendance.objects.all(); serializer_class = AttendanceS
    write_roles = (ADMIN, TEACHER)
    school_path = "student__school"; parent_path = "student__parent"
    filters = {"date": "date", "student": "student_id", "classroom": "student__classroom_id"}

    def extra_save(self):
        return {"marked_by": self.request.user}

    @action(detail=False, methods=["post"])
    def bulk(self, request):
        """{"date": "2026-11-01", "records": [{"student": 1, "status": "P"}, ...]}"""
        d, saved = request.data.get("date") or str(date.today()), 0
        for r in request.data.get("records", []):
            st = Student.objects.filter(pk=r.get("student"), school=request.user.school).first()
            if st and r.get("status") in ("P", "A", "L"):
                Attendance.objects.update_or_create(student=st, date=d,
                    defaults={"status": r["status"], "marked_by": request.user})
                saved += 1
        return Response({"saved": saved})


class FeeVS(ScopedVS):
    queryset = FeeRecord.objects.all(); serializer_class = FeeS
    read_roles = (ADMIN, PARENT)
    school_path = "student__school"; parent_path = "student__parent"
    filters = {"student": "student_id"}

    @action(detail=True, methods=["post"])
    def pay(self, request, pk=None):
        fee = self.get_object()
        try:
            amt = Decimal(str(request.data.get("amount") or 0))
        except Exception:
            amt = Decimal(0)
        if amt <= 0:
            return Response({"error": "Enter a valid amount"}, status=400)
        FeePayment.objects.create(fee=fee, amount=amt, note=request.data.get("note", ""))
        fee.paid_amount += amt; fee.paid_on = date.today(); fee.save()
        return Response({"balance": str(fee.balance)})

    @action(detail=True, methods=["get"])
    def payments(self, request, pk=None):
        fee = self.get_object()
        return Response([{"amount": str(p.amount), "paid_on": p.paid_on, "note": p.note} for p in fee.payments.order_by("-id")])


class MarkVS(ScopedVS):
    queryset = Mark.objects.all(); serializer_class = MarkS
    write_roles = (ADMIN, TEACHER)
    school_path = "student__school"; parent_path = "student__parent"
    filters = {"student": "student_id", "exam": "exam_name"}


class DiaryVS(ScopedVS):
    queryset = Diary.objects.all(); serializer_class = DiaryS
    write_roles = (ADMIN, TEACHER)
    parent_path = "classroom__students__parent"; teacher_path = "teacher"
    filters = {"classroom": "classroom_id", "date": "date"}

    def extra_save(self):
        return {"teacher": self.request.user}


PAR = "classroom__students__parent"


class NoticeVS(ScopedVS):
    queryset = Notice.objects.order_by("-date", "-id"); serializer_class = NoticeS
    parent_all = True

    def extra_save(self):
        return {"posted_by": self.request.user}


class TimetableVS(ScopedVS):
    queryset = Timetable.objects.all(); serializer_class = TimetableS
    parent_path = PAR; teacher_path = "teacher"
    filters = {"classroom": "classroom_id", "day": "day"}


class DateSheetVS(ScopedVS):
    queryset = DateSheet.objects.all(); serializer_class = DateSheetS
    parent_path = PAR
    filters = {"classroom": "classroom_id", "exam": "exam_name"}


class SyllabusVS(ScopedVS):
    queryset = Syllabus.objects.all(); serializer_class = SyllabusS
    write_roles = (ADMIN, TEACHER); parent_path = PAR
    filters = {"classroom": "classroom_id"}


class LessonPlanVS(ScopedVS):
    queryset = LessonPlan.objects.order_by("-date", "-id"); serializer_class = LessonPlanS
    read_roles = (ADMIN, TEACHER); write_roles = (ADMIN, TEACHER); teacher_path = "teacher"
    filters = {"classroom": "classroom_id"}

    def extra_save(self):
        return {"teacher": self.request.user}


class LeaveVS(ScopedVS):
    queryset = Leave.objects.select_related("student", "applicant").order_by("-id"); serializer_class = LeaveS
    write_roles = (ADMIN, TEACHER, PARENT)
    filters = {"status": "status", "kind": "kind"}

    def get_queryset(self):
        u, qs = self.request.user, self.queryset.all()
        if u.role != "SUPER_ADMIN":
            qs = qs.filter(school=u.school)
            if u.role == PARENT:
                qs = qs.filter(applicant=u)
            elif u.role == TEACHER:
                qs = qs.filter(Q(kind="STUDENT") | Q(applicant=u))
        for p, lookup in self.filters.items():
            if self.request.query_params.get(p):
                qs = qs.filter(**{lookup: self.request.query_params[p]})
        return qs

    def perform_create(self, s):
        u = self.request.user
        if u.role == PARENT:
            st = s.validated_data.get("student")
            if not st or st.parent_id != u.id:
                raise PermissionDenied("You can only apply for leave for your own child")
            s.save(school=u.school, applicant=u, kind="STUDENT")
        else:
            s.save(school=u.school, applicant=u, kind="STAFF", student=None)

    def _check_edit(self, obj):
        u = self.request.user
        if u.role in (ADMIN, "SUPER_ADMIN"):
            return
        if obj.applicant_id != u.id or obj.status != "P":
            raise PermissionDenied("You can only edit or delete your own pending leave")

    def perform_update(self, s):
        self._check_edit(s.instance); s.save()

    def perform_destroy(self, inst):
        self._check_edit(inst); inst.delete()

    @action(detail=True, methods=["post"])
    def review(self, request, pk=None):
        lv, u, st = self.get_object(), request.user, request.data.get("status")
        if st not in ("A", "R"):
            return Response({"error": "status must be A or R"}, status=400)
        if u.role == PARENT or (u.role == TEACHER and lv.kind != "STUDENT"):
            raise PermissionDenied("You cannot review this leave")
        if lv.applicant_id == u.id:
            raise PermissionDenied("You cannot approve your own leave")
        lv.status, lv.remark, lv.reviewed_by = st, request.data.get("remark", ""), u
        lv.save()
        return Response({"status": st})


def _brand(b):
    return {"app_name": b.app_name, "color": b.primary_color,
            "logo": f"data:{b.logo_mime};base64,{b.logo_b64}" if b.logo_b64 else ""}


@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def branding(request):
    return Response(_brand(Branding.get()))


@api_view(["GET", "PATCH"])
def super_branding(request):
    if request.user.role != "SUPER_ADMIN":
        raise PermissionDenied("Super Admin only")
    b = Branding.get()
    if request.method == "PATCH":
        name, color = str(request.data.get("app_name", "")).strip(), str(request.data.get("primary_color", "")).strip()
        if color and not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            return Response({"error": "Use #RRGGBB format (for example #3949AB)"}, status=400)
        if name:
            b.app_name = name[:100]
        if color:
            b.primary_color = color
        b.save()
    return Response(_brand(b))
