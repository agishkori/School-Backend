from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from . import models as m

admin.site.register(m.User, UserAdmin)
for x in (m.School, m.ActivationCode, m.ClassRoom, m.Student, m.TeacherProfile,
          m.Attendance, m.FeeRecord, m.Mark, m.Diary, m.Branding, m.Notice, m.Timetable, m.DateSheet,
          m.Syllabus, m.LessonPlan, m.Leave, m.FeePayment):
    admin.site.register(x)
