"""Automatic alerts: absent, marks, fees, notices, diary, date sheet, leaves.
A problem while creating an alert must never block saving the real data, so everything is wrapped in safe()."""
from datetime import date
from functools import wraps
from django.db.models.signals import post_delete, post_save, pre_delete, pre_save
from django.dispatch import receiver
from django.utils import timezone
from .models import *


def safe(fn):
    @wraps(fn)
    def w(*a, **k):
        try:
            return fn(*a, **k)
        except Exception:
            return None
    return w


def _d(v):
    return v if hasattr(v, "strftime") else date.fromisoformat(str(v)[:10])


def _money(x):
    v = float(x)
    return f"{v:,.0f}" if v == int(v) else f"{v:,.2f}"


def _notify(users, title, body, url, kind, key=None):
    from .push import push_users
    push_users(users, title, body, url)
    for u in {x.pk: x for x in users if x and x.is_active}.values():
        if key:
            Notification.objects.update_or_create(user=u, key=key, defaults=dict(
                title=title, body=body[:300], url=url, kind=kind, is_read=False, created_at=timezone.now()))
        else:
            Notification.objects.create(user=u, title=title, body=body[:300], url=url, kind=kind)


def _notify_many(users, title, body, url, kind, key):  # for big groups (all parents)
    from .push import push_users
    users = list(users)
    push_users(users, title, body, url)
    Notification.objects.bulk_create(
        [Notification(user=u, title=title, body=body[:300], url=url, kind=kind, key=key) for u in users],
        ignore_conflicts=True)


def _admins(school):
    return list(User.objects.filter(school=school, role="SCHOOL_ADMIN", is_active=True))


def _class_parents(classroom):
    return User.objects.filter(role="PARENT", is_active=True, children__classroom=classroom).distinct()


@receiver(post_save, sender=Attendance)
@safe
def att_saved(sender, instance, **kw):
    if instance.status == "A":
        st = instance.student
        d = _d(instance.date)
        _notify([st.parent], "Absent", f"{st.name} was marked absent on {d:%d %b %Y}.",
                "/panel/my/attendance/", "absent", f"att:{st.id}:{d}")


@receiver(post_save, sender=Mark)
@safe
def mark_saved(sender, instance, **kw):
    st = instance.student
    _notify([st.parent], "Result updated", f"{st.name}: {instance.exam_name} results have been updated.",
            "/panel/my/results/", "marks", f"marks:{st.id}:{instance.exam_name}")


@receiver(pre_save, sender=FeeRecord)
@safe
def fee_pre(sender, instance, **kw):
    old = FeeRecord.objects.filter(pk=instance.pk).first() if instance.pk else None
    instance._old_paid = old.paid_amount if old else None


@receiver(post_save, sender=FeeRecord)
@safe
def fee_saved(sender, instance, created, **kw):
    st = instance.student
    if created:
        _notify([st.parent], "New fee", f"{instance.title}: Rs {_money(instance.amount)} for {st.name}, due {_d(instance.due_date):%d %b %Y}.",
                "/panel/my/fees/", "fee", f"fee:{instance.id}")
    elif getattr(instance, "_old_paid", None) is not None and instance.paid_amount > instance._old_paid:
        diff = instance.paid_amount - instance._old_paid
        _notify([st.parent], "Payment received",
                f"Rs {_money(diff)} received for {instance.title} ({st.name}). Balance: Rs {_money(instance.amount - instance.paid_amount)}.",
                "/panel/my/fees/", "fee", f"pay:{instance.id}:{instance.paid_amount}")


@receiver(post_save, sender=Notice)
@safe
def notice_saved(sender, instance, created, **kw):
    if created:
        users = User.objects.filter(school=instance.school, role__in=["TEACHER", "PARENT"], is_active=True)
        _notify_many(users.exclude(pk=instance.posted_by_id), "New notice", instance.title,
                     "/panel/my/notices/", "notice", f"notice:{instance.id}")


@receiver(post_save, sender=Diary)
@safe
def diary_saved(sender, instance, created, **kw):
    if created:
        _notify_many(_class_parents(instance.classroom), f"New diary: {instance.subject}", instance.text,
                     "/panel/my/diary/", "diary", f"diary:{instance.id}")


@receiver(post_save, sender=DateSheet)
@safe
def datesheet_saved(sender, instance, created, **kw):
    if created:
        _notify_many(_class_parents(instance.classroom), "Date sheet", f"{instance.exam_name}: {instance.subject} on {_d(instance.date):%d %b %Y}.",
                     "/panel/my/datesheet/", "datesheet", f"ds:{instance.id}")


@receiver(pre_save, sender=Leave)
@safe
def leave_pre(sender, instance, **kw):
    old = Leave.objects.filter(pk=instance.pk).first() if instance.pk else None
    instance._old_status = old.status if old else None


@receiver(post_save, sender=Leave)
@safe
def leave_saved(sender, instance, created, **kw):
    if created:
        who = instance.student.name if instance.kind == "STUDENT" and instance.student else (instance.applicant.first_name or instance.applicant.username)
        boss = _admins(instance.school)
        if instance.kind == "STUDENT" and instance.student and instance.student.classroom:
            boss.append(instance.student.classroom.class_teacher)
        _notify(boss, "New leave request", f"{who}: {_d(instance.from_date):%d %b} to {_d(instance.to_date):%d %b}.",
                "/panel/leaves/", "leave", f"leave-new:{instance.id}")
    elif instance.status in ("A", "R") and getattr(instance, "_old_status", None) != instance.status:
        _notify([instance.applicant], "Leave " + ("approved" if instance.status == "A" else "rejected"),
                f"{_d(instance.from_date):%d %b} to {_d(instance.to_date):%d %b}. {instance.remark}".strip(),
                "/panel/leaves/", "leave", f"leave:{instance.id}")


@receiver(post_save, sender=FeeBalance)
@safe
def fee_balance_saved(sender, instance, **kw):
    st = instance.student
    _notify([st.parent], "Fee balance updated",
            f"{st.name}: remaining balance Rs {_money(instance.balance)}. For any information visit Office.",
            "/panel/my/fees/", "fee", f"feebal:{st.id}")


@receiver(post_delete, sender=Student)
@safe
def student_deleted(sender, instance, **kw):
    """When the last child of a father is deleted, the father's login is deleted too (it must not keep working)."""
    pid = instance.parent_id
    if pid and not Student.objects.filter(parent_id=pid).exists():
        User.objects.filter(pk=pid, role="PARENT").delete()


@receiver(pre_delete, sender=ClassRoom)
@safe
def class_deleting(sender, instance, **kw):
    """Deleting a class removes its students (and their fees, results, attendance and the fathers' logins) for good."""
    Student.objects.filter(classroom=instance).delete()


@receiver(pre_delete, sender=User)
@safe
def teacher_deleting(sender, instance, **kw):
    """A deleted teacher leaves no timetable periods or diary behind."""
    if instance.role == "TEACHER":
        Timetable.objects.filter(teacher=instance).delete()
        Diary.objects.filter(teacher=instance).delete()


@receiver(post_save, sender=ChatMessage)
@safe
def chat_pushed(sender, instance, created, **kw):
    if created:
        from .push import push_users
        who = instance.sender.first_name or instance.sender.username
        push_users([instance.recipient], f"Message from {who}", instance.text, f"/panel/chats/{instance.sender_id}/")
