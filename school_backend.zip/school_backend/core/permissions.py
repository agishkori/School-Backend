from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsSuperAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == "SUPER_ADMIN"


class RolePermission(BasePermission):
    """Access by the view's read_roles / write_roles; the school must be valid."""
    def has_permission(self, request, view):
        u = request.user
        if not u.is_authenticated:
            return False
        if u.role == "SUPER_ADMIN":
            return True
        if not (u.school and u.school.is_valid()):
            return False
        roles = view.read_roles if request.method in SAFE_METHODS else view.write_roles
        return u.role in roles
