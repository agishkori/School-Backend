from datetime import date
from django.contrib.auth.models import AbstractUser
from django.db import models


class School(models.Model):
    name = models.CharField(max_length=150)
    is_active = models.BooleanField(default=False)  # becomes True once activated with a code
    expires_on = models.DateField()
    max_students = models.PositiveIntegerField(default=500)

    def is_valid(self):
        return self.is_active and self.expires_on >= date.today()

    def __str__(self):
        return self.name


class ActivationCode(models.Model):
    code = models.CharField(max_length=20, unique=True)
    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name="codes")
    used_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class User(AbstractUser):
    ROLES = [("SUPER_ADMIN", "Super Admin"), ("SCHOOL_ADMIN", "School Admin"),
             ("TEACHER", "Teacher"), ("PARENT", "Parent")]
    role = models.CharField(max_length=15, choices=ROLES, default="PARENT")
    school = models.ForeignKey(School, null=True, blank=True, on_delete=models.CASCADE)
    phone = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return self.first_name or self.username

    def save(self, *a, **k):
        if self.is_superuser:
            self.role = "SUPER_ADMIN"
        super().save(*a, **k)


class ClassRoom(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    section = models.CharField(max_length=10, blank=True)
    class_teacher = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return f"{self.name} {self.section}".strip()


class Student(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    classroom = models.ForeignKey(ClassRoom, null=True, blank=True, on_delete=models.SET_NULL, related_name="students")
    parent = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="children")
    name = models.CharField(max_length=120)
    roll_no = models.CharField(max_length=20)
    phone = models.CharField(max_length=20, blank=True)
    admission_date = models.DateField(default=date.today)

    def __str__(self):
        return f"{self.name} ({self.roll_no})"


class TeacherProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="teacher_profile")
    subject = models.CharField(max_length=100, blank=True)
    qualification = models.CharField(max_length=100, blank=True)
    salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)


class Attendance(models.Model):
    STATUS = [("P", "Present"), ("A", "Absent"), ("L", "Leave")]
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(default=date.today)
    status = models.CharField(max_length=1, choices=STATUS, default="P")
    marked_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)

    class Meta:
        unique_together = ("student", "date")


class FeeRecord(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    paid_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    due_date = models.DateField()
    paid_on = models.DateField(null=True, blank=True)

    @property
    def balance(self):
        return self.amount - self.paid_amount


class Mark(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    exam_name = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    total = models.PositiveIntegerField(default=100)
    obtained = models.DecimalField(max_digits=6, decimal_places=2)

    @property
    def percentage(self):
        return round(float(self.obtained) / self.total * 100, 1) if self.total else 0


class Diary(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    teacher = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    subject = models.CharField(max_length=100)
    text = models.TextField()
    date = models.DateField(default=date.today)


class Branding(models.Model):  # Super admin: app name / color / logo
    app_name = models.CharField(max_length=100, default="School Manager")
    primary_color = models.CharField(max_length=9, default="#3949ab")
    logo_b64 = models.TextField(blank=True)
    logo_mime = models.CharField(max_length=30, blank=True)

    @classmethod
    def get(cls):
        return cls.objects.get_or_create(pk=1)[0]


class Notice(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    title = models.CharField(max_length=150)
    body = models.TextField(blank=True)
    posted_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    date = models.DateField(default=date.today)


class Timetable(models.Model):  # day: 1=Mon ... 7=Sun
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    day = models.PositiveSmallIntegerField(default=1)
    period = models.PositiveSmallIntegerField(default=1)
    subject = models.CharField(max_length=100)
    teacher = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    start_time = models.CharField(max_length=10, blank=True)
    end_time = models.CharField(max_length=10, blank=True)

    class Meta:
        ordering = ["day", "period"]


class DateSheet(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    exam_name = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    start_time = models.CharField(max_length=10, blank=True)
    note = models.CharField(max_length=200, blank=True)
    date = models.DateField()

    class Meta:
        ordering = ["date"]


class Syllabus(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    title = models.CharField(max_length=150)
    details = models.TextField(blank=True)


class LessonPlan(models.Model):
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    classroom = models.ForeignKey(ClassRoom, on_delete=models.CASCADE)
    teacher = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    subject = models.CharField(max_length=100)
    topic = models.CharField(max_length=200)
    plan = models.TextField(blank=True)
    date = models.DateField(default=date.today)


class Leave(models.Model):
    KINDS = [("STUDENT", "Student"), ("STAFF", "Staff")]
    STATUS = [("P", "Pending"), ("A", "Approved"), ("R", "Rejected")]
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    kind = models.CharField(max_length=7, choices=KINDS)
    student = models.ForeignKey(Student, null=True, blank=True, on_delete=models.CASCADE)
    applicant = models.ForeignKey(User, on_delete=models.CASCADE, related_name="leaves")
    from_date = models.DateField()
    to_date = models.DateField()
    reason = models.CharField(max_length=300, blank=True)
    status = models.CharField(max_length=1, choices=STATUS, default="P")
    remark = models.CharField(max_length=200, blank=True)
    reviewed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")


class FeePayment(models.Model):
    fee = models.ForeignKey(FeeRecord, on_delete=models.CASCADE, related_name="payments")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    note = models.CharField(max_length=100, blank=True)
    paid_on = models.DateField(default=date.today)


from django.utils import timezone  # noqa: E402


class Notification(models.Model):  # alerts shown in the app (absent, marks, fees, notices, leaves ...)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")
    title = models.CharField(max_length=120)
    body = models.CharField(max_length=300, blank=True)
    url = models.CharField(max_length=200, default="/panel/alerts/")
    kind = models.CharField(max_length=12, default="info")
    key = models.CharField(max_length=80, null=True, blank=True)  # same key = update, not duplicate
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-created_at", "-id"]
        unique_together = ("user", "key")


class ChatMessage(models.Model):  # parent <-> teacher / admin chat
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="chat_sent")
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name="chat_received")
    text = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    is_read = models.BooleanField(default=False)
