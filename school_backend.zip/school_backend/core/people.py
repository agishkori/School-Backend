"""Father CNIC helpers: login name, parent account linking, child selection."""
import re
from django.db.models import Q
from .models import ClassRoom, Student, Timetable, User


def norm_cnic(v):
    """'35202-1234567-1' -> '3520212345671'; returns '' unless exactly 13 digits."""
    d = re.sub(r"\D", "", str(v or ""))
    return d if len(d) == 13 else ""


def fmt_cnic(v):
    d = norm_cnic(v)
    return f"{d[:5]}-{d[5:12]}-{d[12]}" if d else str(v or "")


def login_name(raw):
    """Parents type the CNIC (with or without dashes); teachers/admins type their login ID."""
    raw = (raw or "").strip()
    return norm_cnic(raw) or raw


def link_parent(student, password=None):
    """Make sure the father's account exists and the student is linked to it.
    Returns (user or None, password_set_or_None)."""
    cnic = norm_cnic(student.father_cnic)
    if not cnic:
        return None, None
    user = User.objects.filter(username=cnic).first()
    given = None
    if user is None:
        given = password or cnic[-6:]
        user = User.objects.create_user(username=cnic, password=given, first_name=student.father_name,
                                        role="PARENT", school=student.school)
    elif user.school_id != student.school_id or user.role != "PARENT":
        raise ValueError(f"CNIC {fmt_cnic(cnic)} already belongs to another account")
    elif student.father_name and not user.first_name:
        user.first_name = student.father_name; user.save()
    if student.parent_id != user.id:
        student.parent = user
        Student.objects.filter(pk=student.pk).update(parent=user)
    return user, given


def children_of(request):
    """(all children of the logged-in parent, the selected one). Selection is kept in the session."""
    u = request.user
    kids = list(Student.objects.filter(school=u.school, parent=u).select_related("classroom").order_by("name"))
    cur = next((k for k in kids if str(k.id) == str(request.session.get("child"))), kids[0] if kids else None)
    return kids, cur


def teacher_rooms(u):
    """Classes a teacher may open: the class assigned to him/her by the admin (class teacher) or where the timetable gives him/her a period."""
    return ClassRoom.objects.filter(school=u.school).filter(
        Q(class_teacher=u) | Q(pk__in=Timetable.objects.filter(school=u.school, teacher=u).values("classroom")))
