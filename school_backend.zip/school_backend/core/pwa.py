"""Installable web app (PWA): manifest, service worker and icons built from the Super Admin's branding."""
import base64, hashlib, io
from django.http import Http404, HttpResponse, JsonResponse
from .models import Branding

_CACHE = {}


def _brand(request=None):
    from .look import look_for
    from .models import School
    sid = request.GET.get("s") if request is not None else None
    return look_for(School.objects.filter(pk=sid).first() if sid and sid.isdigit() else None)


def _rgb(c):
    try:
        c = c.lstrip("#")
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return (57, 73, 171)


def _icon_bytes(size, b):
    from PIL import Image, ImageDraw, ImageFont
    key = (size, b.icon_shape, b.primary_color, b.app_name[:1], hashlib.md5((b.logo_b64 or "").encode()).hexdigest())
    if key in _CACHE:
        return _CACHE[key]
    img = Image.new("RGBA", (size, size), _rgb(b.primary_color) + (255,))
    done = False
    if b.logo_b64:
        try:
            logo = Image.open(io.BytesIO(base64.b64decode(b.logo_b64))).convert("RGBA")
            box = int(size * 0.72)
            logo.thumbnail((box, box))
            img.paste(logo, ((size - logo.width) // 2, (size - logo.height) // 2), logo)
            done = True
        except Exception:
            pass
    if not done:  # no logo: first letter of the app name on the brand color
        d = ImageDraw.Draw(img)
        letter = (b.app_name.strip()[:1] or "S").upper()
        try:
            font = ImageFont.load_default(size=int(size * 0.55))
        except TypeError:
            font = ImageFont.load_default()
        bb = d.textbbox((0, 0), letter, font=font)
        d.text(((size - (bb[2] - bb[0])) / 2 - bb[0], (size - (bb[3] - bb[1])) / 2 - bb[1]), letter,
               fill=(255, 255, 255, 255), font=font)
    if b.icon_shape in ("round", "rounded"):  # cut the icon to the school's chosen shape
        m = Image.new("L", (size, size), 0)
        d2 = ImageDraw.Draw(m)
        if b.icon_shape == "round":
            d2.ellipse((0, 0, size - 1, size - 1), fill=255)
        else:
            d2.rounded_rectangle((0, 0, size - 1, size - 1), radius=int(size * 0.22), fill=255)
        img.putalpha(m)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    if len(_CACHE) > 40:
        _CACHE.clear()
    _CACHE[key] = buf.getvalue()
    return _CACHE[key]


def icon(request, size):
    if size not in (180, 192, 512):
        raise Http404
    r = HttpResponse(_icon_bytes(size, _brand(request)), content_type="image/png")
    r["Cache-Control"] = "public, max-age=300"
    return r


def manifest(request):
    b = _brand(request)
    q = f"?s={b.school_id}" if b.school_id else ""
    r = JsonResponse({
        "name": b.app_name, "short_name": b.app_name[:12], "start_url": "/panel/", "scope": "/", "id": "/panel/",
        "display": "standalone", "orientation": "portrait", "background_color": "#ffffff",
        "theme_color": b.primary_color,
        "icons": [{"src": "/pwa/icon-192.png" + q, "sizes": "192x192", "type": "image/png", "purpose": "any"},
                  {"src": "/pwa/icon-512.png" + q, "sizes": "512x512", "type": "image/png", "purpose": "any"},
                  {"src": "/pwa/icon-512.png" + q, "sizes": "512x512", "type": "image/png", "purpose": "maskable"}],
    }, content_type="application/manifest+json")
    r["Cache-Control"] = "no-cache"
    return r


def service_worker(request):
    js = ("self.addEventListener('install',function(e){self.skipWaiting()});\n"
          "self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim())});\n"
          "self.addEventListener('fetch',function(e){});\n")  # no caching: pages are always fresh from the server
    r = HttpResponse(js, content_type="application/javascript")
    r["Service-Worker-Allowed"] = "/"
    r["Cache-Control"] = "no-cache"
    return r
