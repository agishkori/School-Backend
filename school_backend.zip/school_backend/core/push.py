"""Phone push notifications (Web Push). Works even when the app is closed. Never blocks or breaks the real action."""
import base64, json, threading
from .models import PushSub, VapidKey


def _keys():
    k = VapidKey.objects.first()
    if k:
        return k
    from cryptography.hazmat.primitives import serialization
    from py_vapid import Vapid
    v = Vapid(); v.generate_keys()
    pem = v.private_pem().decode()
    pub = base64.urlsafe_b64encode(v.public_key.public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)).decode().rstrip("=")
    return VapidKey.objects.create(private_pem=pem, public_key=pub)


def public_key():
    return _keys().public_key


def _send(items, payload):
    from pywebpush import webpush, WebPushException
    from django.db import close_old_connections
    try:
        pem = _keys().private_pem
        for sid, endpoint, p256dh, auth in items:
            try:
                webpush(subscription_info={"endpoint": endpoint, "keys": {"p256dh": p256dh, "auth": auth}},
                        data=payload, vapid_private_key=pem, vapid_claims={"sub": "mailto:admin@school.local"}, ttl=86400)
            except WebPushException as e:
                if getattr(e.response, "status_code", 0) in (404, 410):
                    PushSub.objects.filter(pk=sid).delete()
            except Exception:
                pass
    finally:
        close_old_connections()


def push_users(users, title, body="", url="/panel/alerts/", wait=False):
    """Send a pop-up to every phone of these users (in the background)."""
    try:
        ids = [u.pk if hasattr(u, "pk") else u for u in users if u]
        items = list(PushSub.objects.filter(user_id__in=ids).values_list("id", "endpoint", "p256dh", "auth"))
        if not items:
            return
        payload = json.dumps({"title": title[:100], "body": body[:200], "url": url})
        t = threading.Thread(target=_send, args=(items, payload), daemon=True)
        t.start()
        if wait:
            t.join()
    except Exception:
        pass
