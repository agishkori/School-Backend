"""Icon tiles for the home screen, per role."""
TINTS = ["#fff3e0", "#e8f0fe", "#ffe9e6", "#e8f5e9", "#ede7f6", "#e0f7fa", "#fce4ec", "#e8eaf6", "#e0f2f1", "#eceff1", "#fff8e1", "#f3e5f5"]
ROLE_LABEL = {"SCHOOL_ADMIN": "Admin", "TEACHER": "Teacher", "PARENT": "Student / Parent", "SUPER_ADMIN": "Super Admin"}


def _tiles(items):
    return [{"title": t, "url": u, "icon": i, "tint": TINTS[n % len(TINTS)]} for n, (t, u, i) in enumerate(items)]


TILES = {
    "PARENT": _tiles([("Attendance", "/panel/my/attendance/", "✅"), ("Fees", "/panel/my/fees/", "💰"), ("Results", "/panel/my/results/", "📊"),
                      ("Diary", "/panel/my/diary/", "📖"), ("Date Sheet", "/panel/my/datesheet/", "📄"),
                      ("Syllabus", "/panel/my/syllabus/", "📋"), ("Notice Board", "/panel/my/notices/", "📢"), ("Leaves", "/panel/leaves/", "📝"), ("PDF Files", "/panel/docs/", "📄")]),
    "TEACHER": _tiles([("Attendance", "/panel/attendance/", "✅"), ("Lesson Plans", "/panel/m/lessonplans/", "🧑‍🏫"), ("Diary", "/panel/m/diary/", "📖"),
                       ("Syllabus", "/panel/m/syllabus/", "📋"), ("Results", "/panel/rec/results/", "📊"), ("Timetable", "/panel/my/timetable/", "🗓️"),
                       ("Date Sheet", "/panel/my/datesheet/", "📄"), ("Notice Board", "/panel/my/notices/", "📢"), ("Students", "/panel/my/students/", "👥"),
                       ("Student Leaves", "/panel/leaves/", "📝"), ("PDF Files", "/panel/docs/", "📄")]),
    "SCHOOL_ADMIN": _tiles([("Classes", "/panel/m/classes/", "🏫"), ("Students", "/panel/rec/students/", "🎓"), ("Accounts", "/panel/accounts/", "👥"),
                            ("Attendance", "/panel/attendance/", "✅"), ("Fees", "/panel/rec/fees/", "💰"), ("Results", "/panel/rec/results/", "📊"),
                            ("Notice Board", "/panel/m/notices/", "📢"), ("Timetable", "/panel/m/timetable/", "🗓️"), ("Date Sheet", "/panel/m/datesheet/", "📄"),
                            ("Syllabus", "/panel/m/syllabus/", "📋"), ("Lesson Plans", "/panel/m/lessonplans/", "🧑‍🏫"), ("Diary", "/panel/m/diary/", "📖"),
                            ("Leaves", "/panel/leaves/", "📝"),
                            ("PDF Files", "/panel/docs/", "📄"), ("School Profile", "/panel/school/", "🎨")]),
}
