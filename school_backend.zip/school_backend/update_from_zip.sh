#!/bin/bash
# Update the server from the school_backend.zip you uploaded to GitHub:   bash update_from_zip.sh
# Your database (db.sqlite3) and venv are NOT inside the zip, so they are never touched.
{
set -e
PROJECT="$(cd "$(dirname "$0")" && pwd)"   # e.g. /home/USER/School-Backend/school_backend
REPO="$(dirname "$PROJECT")"               # e.g. /home/USER/School-Backend
cd "$REPO"
git pull
mkdir -p ~/db_backups
if [ -f "$PROJECT/db.sqlite3" ]; then
  cp "$PROJECT/db.sqlite3" ~/db_backups/before_update_$(date +%Y-%m-%d_%H%M%S).sqlite3
  echo "Backup saved in ~/db_backups"
fi
unzip -o -q "$REPO/school_backend.zip" -d "$REPO"
cd "$PROJECT"
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
touch /var/www/*wsgi.py 2>/dev/null && echo "Done. App reloaded." || echo "Done. Now click Reload on the Web tab."
exit
}
